package safenet.jcprov;

public class CK_SLOT_INFO {
  public byte[] slotDescription = new byte[64];
  
  public byte[] manufacturerID = new byte[32];
  
  public long flags;
  
  public CK_VERSION hardwareVersion = new CK_VERSION();
  
  public CK_VERSION firmwareVersion = new CK_VERSION();
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/CK_SLOT_INFO.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */