package safenet.jcprov;

import safenet.jcprov.constants.CKR;
import safenet.jcprov.constants.CK_MECHANISM_TYPE;
import safenet.jcprov.constants.CK_RV;
import safenet.jcprov.constants.CK_USER_TYPE;

public class CryptokiEx {
  public static CK_RV C_Initialize(CK_C_INITIALIZE_ARGS paramCK_C_INITIALIZE_ARGS) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_Initialize(paramCK_C_INITIALIZE_ARGS);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_Initialize", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_Finalize(Object paramObject) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_Finalize(paramObject);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_Finalize", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_GetInfo(CK_INFO paramCK_INFO) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_GetInfo(paramCK_INFO);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_GetInfo", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_GetSlotList(CK_BBOOL paramCK_BBOOL, long[] paramArrayOflong, LongRef paramLongRef) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_GetSlotList(paramCK_BBOOL, paramArrayOflong, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_GetSlotList", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_GetSlotInfo(long paramLong, CK_SLOT_INFO paramCK_SLOT_INFO) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_GetSlotInfo(paramLong, paramCK_SLOT_INFO);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_GetSlotInfo", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_GetTokenInfo(long paramLong, CK_TOKEN_INFO paramCK_TOKEN_INFO) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_GetTokenInfo(paramLong, paramCK_TOKEN_INFO);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_GetTokenInfo", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_GetMechanismList(long paramLong, CK_MECHANISM_TYPE[] paramArrayOfCK_MECHANISM_TYPE, LongRef paramLongRef) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_GetMechanismList(paramLong, paramArrayOfCK_MECHANISM_TYPE, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_GetMechanismList", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_GetMechanismInfo(long paramLong, CK_MECHANISM_TYPE paramCK_MECHANISM_TYPE, CK_MECHANISM_INFO paramCK_MECHANISM_INFO) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_GetMechanismInfo(paramLong, paramCK_MECHANISM_TYPE, paramCK_MECHANISM_INFO);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_GetMechanismInfo", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_InitToken(long paramLong1, byte[] paramArrayOfbyte1, long paramLong2, byte[] paramArrayOfbyte2) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_InitToken(paramLong1, paramArrayOfbyte1, paramLong2, paramArrayOfbyte2);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_InitToken", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_InitPIN(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, long paramLong) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_InitPIN(paramCK_SESSION_HANDLE, paramArrayOfbyte, paramLong);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_InitPIN", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_SetPIN(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong1, byte[] paramArrayOfbyte2, long paramLong2) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_SetPIN(paramCK_SESSION_HANDLE, paramArrayOfbyte1, paramLong1, paramArrayOfbyte2, paramLong2);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_SetPIN", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_OpenSession(long paramLong1, long paramLong2, Object paramObject1, Object paramObject2, CK_SESSION_HANDLE paramCK_SESSION_HANDLE) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_OpenSession(paramLong1, paramLong2, paramObject1, paramObject2, paramCK_SESSION_HANDLE);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_OpenSession", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_CloseSession(CK_SESSION_HANDLE paramCK_SESSION_HANDLE) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_CloseSession(paramCK_SESSION_HANDLE);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_CloseSession", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_CloseAllSessions(long paramLong) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_CloseAllSessions(paramLong);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_CloseAllSessions", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_GetSessionInfo(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_SESSION_INFO paramCK_SESSION_INFO) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_GetSessionInfo(paramCK_SESSION_HANDLE, paramCK_SESSION_INFO);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_GetSessionInfo", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_GetOperationState(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, LongRef paramLongRef) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_GetOperationState(paramCK_SESSION_HANDLE, paramArrayOfbyte, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_GetOperationState", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_SetOperationState(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, long paramLong, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE1, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE2) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_SetOperationState(paramCK_SESSION_HANDLE, paramArrayOfbyte, paramLong, paramCK_OBJECT_HANDLE1, paramCK_OBJECT_HANDLE2);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_SetOperationState", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_Login(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_USER_TYPE paramCK_USER_TYPE, byte[] paramArrayOfbyte, long paramLong) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_Login(paramCK_SESSION_HANDLE, paramCK_USER_TYPE, paramArrayOfbyte, paramLong);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_Login", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_Logout(CK_SESSION_HANDLE paramCK_SESSION_HANDLE) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_Logout(paramCK_SESSION_HANDLE);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_Logout", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_CreateObject(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE, long paramLong, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_CreateObject(paramCK_SESSION_HANDLE, paramArrayOfCK_ATTRIBUTE, paramLong, paramCK_OBJECT_HANDLE);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_CreateObject", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_CopyObject(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE1, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE, long paramLong, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE2) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_CopyObject(paramCK_SESSION_HANDLE, paramCK_OBJECT_HANDLE1, paramArrayOfCK_ATTRIBUTE, paramLong, paramCK_OBJECT_HANDLE2);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_CopyObject", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_DestroyObject(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_DestroyObject(paramCK_SESSION_HANDLE, paramCK_OBJECT_HANDLE);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_DestroyObject", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_GetObjectSize(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE, LongRef paramLongRef) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_GetObjectSize(paramCK_SESSION_HANDLE, paramCK_OBJECT_HANDLE, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_GetObjectSize", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_GetAttributeValue(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE, long paramLong) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_GetAttributeValue(paramCK_SESSION_HANDLE, paramCK_OBJECT_HANDLE, paramArrayOfCK_ATTRIBUTE, paramLong);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_GetAttributeValue", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_SetAttributeValue(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE, long paramLong) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_SetAttributeValue(paramCK_SESSION_HANDLE, paramCK_OBJECT_HANDLE, paramArrayOfCK_ATTRIBUTE, paramLong);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_SetAttributeValue", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_FindObjectsInit(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE, long paramLong) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_FindObjectsInit(paramCK_SESSION_HANDLE, paramArrayOfCK_ATTRIBUTE, paramLong);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_FindObjectsInit", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_FindObjects(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_OBJECT_HANDLE[] paramArrayOfCK_OBJECT_HANDLE, long paramLong, LongRef paramLongRef) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_FindObjects(paramCK_SESSION_HANDLE, paramArrayOfCK_OBJECT_HANDLE, paramLong, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_FindObjects", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_FindObjectsFinal(CK_SESSION_HANDLE paramCK_SESSION_HANDLE) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_FindObjectsFinal(paramCK_SESSION_HANDLE);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_FindObjectsFinal", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_EncryptInit(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_EncryptInit(paramCK_SESSION_HANDLE, paramCK_MECHANISM, paramCK_OBJECT_HANDLE);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_EncryptInit", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_Encrypt(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_Encrypt(paramCK_SESSION_HANDLE, paramArrayOfbyte1, paramLong, paramArrayOfbyte2, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_Encrypt", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_EncryptUpdate(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_EncryptUpdate(paramCK_SESSION_HANDLE, paramArrayOfbyte1, paramLong, paramArrayOfbyte2, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_EncryptUpdate", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_EncryptFinal(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, LongRef paramLongRef) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_EncryptFinal(paramCK_SESSION_HANDLE, paramArrayOfbyte, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_EncryptFinal", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_DecryptInit(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_DecryptInit(paramCK_SESSION_HANDLE, paramCK_MECHANISM, paramCK_OBJECT_HANDLE);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_DecryptInit", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_Decrypt(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_Decrypt(paramCK_SESSION_HANDLE, paramArrayOfbyte1, paramLong, paramArrayOfbyte2, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_Decrypt", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_DecryptUpdate(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_DecryptUpdate(paramCK_SESSION_HANDLE, paramArrayOfbyte1, paramLong, paramArrayOfbyte2, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_DecryptUpdate", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_DecryptFinal(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, LongRef paramLongRef) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_DecryptFinal(paramCK_SESSION_HANDLE, paramArrayOfbyte, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_DecryptFinal", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_DigestInit(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_DigestInit(paramCK_SESSION_HANDLE, paramCK_MECHANISM);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_DigestInit", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_Digest(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_Digest(paramCK_SESSION_HANDLE, paramArrayOfbyte1, paramLong, paramArrayOfbyte2, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_Digest", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_DigestUpdate(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, long paramLong) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_DigestUpdate(paramCK_SESSION_HANDLE, paramArrayOfbyte, paramLong);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_DigestUpdate", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_DigestKey(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_DigestKey(paramCK_SESSION_HANDLE, paramCK_OBJECT_HANDLE);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_DigestKey", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_DigestFinal(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, LongRef paramLongRef) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_DigestFinal(paramCK_SESSION_HANDLE, paramArrayOfbyte, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_DigestFinal", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_SignInit(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_SignInit(paramCK_SESSION_HANDLE, paramCK_MECHANISM, paramCK_OBJECT_HANDLE);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_SignInit", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_Sign(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_Sign(paramCK_SESSION_HANDLE, paramArrayOfbyte1, paramLong, paramArrayOfbyte2, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_Sign", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_SignUpdate(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, long paramLong) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_SignUpdate(paramCK_SESSION_HANDLE, paramArrayOfbyte, paramLong);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_SignUpdate", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_SignFinal(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, LongRef paramLongRef) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_SignFinal(paramCK_SESSION_HANDLE, paramArrayOfbyte, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_SignFinal", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_SignRecoverInit(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_SignRecoverInit(paramCK_SESSION_HANDLE, paramCK_MECHANISM, paramCK_OBJECT_HANDLE);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_SignRecoverInit", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_SignRecover(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_SignRecover(paramCK_SESSION_HANDLE, paramArrayOfbyte1, paramLong, paramArrayOfbyte2, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_SignRecover", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_VerifyInit(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_VerifyInit(paramCK_SESSION_HANDLE, paramCK_MECHANISM, paramCK_OBJECT_HANDLE);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_VerifyInit", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_Verify(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong1, byte[] paramArrayOfbyte2, long paramLong2) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_Verify(paramCK_SESSION_HANDLE, paramArrayOfbyte1, paramLong1, paramArrayOfbyte2, paramLong2);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_Verify", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_VerifyUpdate(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, long paramLong) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_VerifyUpdate(paramCK_SESSION_HANDLE, paramArrayOfbyte, paramLong);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_VerifyUpdate", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_VerifyFinal(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, long paramLong) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_VerifyFinal(paramCK_SESSION_HANDLE, paramArrayOfbyte, paramLong);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_VerifyFinal", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_VerifyRecoverInit(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_VerifyRecoverInit(paramCK_SESSION_HANDLE, paramCK_MECHANISM, paramCK_OBJECT_HANDLE);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_VerifyRecoverInit", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_VerifyRecover(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_VerifyRecover(paramCK_SESSION_HANDLE, paramArrayOfbyte1, paramLong, paramArrayOfbyte2, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_VerifyRecover", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_DigestEncryptUpdate(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_DigestEncryptUpdate(paramCK_SESSION_HANDLE, paramArrayOfbyte1, paramLong, paramArrayOfbyte2, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_DigestEncryptUpdate", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_DecryptDigestUpdate(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_DecryptDigestUpdate(paramCK_SESSION_HANDLE, paramArrayOfbyte1, paramLong, paramArrayOfbyte2, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_DecryptDigestUpdate", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_SignEncryptUpdate(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_SignEncryptUpdate(paramCK_SESSION_HANDLE, paramArrayOfbyte1, paramLong, paramArrayOfbyte2, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_SignEncryptUpdate", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_DecryptVerifyUpdate(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_DecryptVerifyUpdate(paramCK_SESSION_HANDLE, paramArrayOfbyte1, paramLong, paramArrayOfbyte2, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_DecryptVerifyUpdate", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_GenerateKey(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE, long paramLong, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_GenerateKey(paramCK_SESSION_HANDLE, paramCK_MECHANISM, paramArrayOfCK_ATTRIBUTE, paramLong, paramCK_OBJECT_HANDLE);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_GenerateKey", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_GenerateKeyPair(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE1, long paramLong1, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE2, long paramLong2, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE1, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE2) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_GenerateKeyPair(paramCK_SESSION_HANDLE, paramCK_MECHANISM, paramArrayOfCK_ATTRIBUTE1, paramLong1, paramArrayOfCK_ATTRIBUTE2, paramLong2, paramCK_OBJECT_HANDLE1, paramCK_OBJECT_HANDLE2);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_GenerateKeyPair", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_WrapKey(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE1, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE2, byte[] paramArrayOfbyte, LongRef paramLongRef) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_WrapKey(paramCK_SESSION_HANDLE, paramCK_MECHANISM, paramCK_OBJECT_HANDLE1, paramCK_OBJECT_HANDLE2, paramArrayOfbyte, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_WrapKey", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_UnwrapKey(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE1, byte[] paramArrayOfbyte, long paramLong1, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE, long paramLong2, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE2) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_UnwrapKey(paramCK_SESSION_HANDLE, paramCK_MECHANISM, paramCK_OBJECT_HANDLE1, paramArrayOfbyte, paramLong1, paramArrayOfCK_ATTRIBUTE, paramLong2, paramCK_OBJECT_HANDLE2);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_UnwrapKey", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_DeriveKey(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE1, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE, long paramLong, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE2) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_DeriveKey(paramCK_SESSION_HANDLE, paramCK_MECHANISM, paramCK_OBJECT_HANDLE1, paramArrayOfCK_ATTRIBUTE, paramLong, paramCK_OBJECT_HANDLE2);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_DeriveKey", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_SeedRandom(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, long paramLong) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_SeedRandom(paramCK_SESSION_HANDLE, paramArrayOfbyte, paramLong);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_SeedRandom", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_GenerateRandom(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, long paramLong) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_GenerateRandom(paramCK_SESSION_HANDLE, paramArrayOfbyte, paramLong);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_GenerateRandom", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_GetFunctionStatus(CK_SESSION_HANDLE paramCK_SESSION_HANDLE) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_GetFunctionStatus(paramCK_SESSION_HANDLE);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_GetFunctionStatus", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_CancelFunction(CK_SESSION_HANDLE paramCK_SESSION_HANDLE) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_CancelFunction(paramCK_SESSION_HANDLE);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_CancelFunction", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV C_WaitForSlotEvent(long paramLong, LongRef paramLongRef, Object paramObject) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.C_WaitForSlotEvent(paramLong, paramLongRef, paramObject);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("C_WaitForSlotEvent", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV CT_InitToken(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, long paramLong1, byte[] paramArrayOfbyte1, long paramLong2, byte[] paramArrayOfbyte2) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.CT_InitToken(paramCK_SESSION_HANDLE, paramLong1, paramArrayOfbyte1, paramLong2, paramArrayOfbyte2);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("CT_InitToken", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV CT_ResetToken(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.CT_ResetToken(paramCK_SESSION_HANDLE, paramArrayOfbyte1, paramLong, paramArrayOfbyte2);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("CT_ResetToken", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV CT_CopyObject(CK_SESSION_HANDLE paramCK_SESSION_HANDLE1, CK_SESSION_HANDLE paramCK_SESSION_HANDLE2, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE1, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE, long paramLong, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE2) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.CT_CopyObject(paramCK_SESSION_HANDLE1, paramCK_SESSION_HANDLE2, paramCK_OBJECT_HANDLE1, paramArrayOfCK_ATTRIBUTE, paramLong, paramCK_OBJECT_HANDLE2);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("CT_CopyObject", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV FMSC_SendReceive(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, int paramInt, byte[] paramArrayOfbyte1, long paramLong1, byte[] paramArrayOfbyte2, long paramLong2, LongRef paramLongRef1, LongRef paramLongRef2) throws CKR_Exception {
    CK_RV cK_RV = Cryptoki.FMSC_SendReceive(paramCK_SESSION_HANDLE, paramInt, paramArrayOfbyte1, paramLong1, paramArrayOfbyte2, paramLong2, paramLongRef1, paramLongRef2);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("FMSC_SendReceive", cK_RV); 
    return cK_RV;
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/CryptokiEx.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */