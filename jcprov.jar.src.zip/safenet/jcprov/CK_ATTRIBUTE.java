package safenet.jcprov;

import safenet.jcprov.constants.CK_ATTRIBUTE_TYPE;

public class CK_ATTRIBUTE {
  public CK_ATTRIBUTE_TYPE type;
  
  public Object pValue;
  
  public long valueLen;
  
  public CK_ATTRIBUTE() {}
  
  public CK_ATTRIBUTE(CK_ATTRIBUTE_TYPE paramCK_ATTRIBUTE_TYPE, Object paramObject, long paramLong) {
    this.type = paramCK_ATTRIBUTE_TYPE;
    this.pValue = paramObject;
    this.valueLen = paramLong;
  }
  
  public CK_ATTRIBUTE(CK_ATTRIBUTE_TYPE paramCK_ATTRIBUTE_TYPE, Object paramObject) {
    this.type = paramCK_ATTRIBUTE_TYPE;
    this.pValue = paramObject;
    this.valueLen = getAttributeValueSize(paramObject);
  }
  
  public CK_ATTRIBUTE(CK_ATTRIBUTE_TYPE paramCK_ATTRIBUTE_TYPE, int paramInt) {
    this.type = paramCK_ATTRIBUTE_TYPE;
    this.pValue = new Integer(paramInt);
    this.valueLen = getAttributeValueSize(this.pValue);
  }
  
  public static long getAttributeValueSize(Object paramObject) {
    return (paramObject instanceof byte[]) ? ((byte[])paramObject).length : ((paramObject instanceof Long) ? 4L : ((paramObject instanceof Integer) ? 4L : ((paramObject instanceof CK_BBOOL) ? 1L : ((paramObject instanceof CK_DATE) ? 8L : ((paramObject instanceof CK_OBJECT_HANDLE) ? 4L : ((paramObject instanceof CK_SESSION_HANDLE) ? 4L : ((paramObject instanceof CK_ATTRIBUTE_TYPE) ? 4L : ((paramObject instanceof safenet.jcprov.constants.CK_CERTIFICATE_TYPE) ? 4L : ((paramObject instanceof safenet.jcprov.constants.CK_HW_FEATURE_TYPE) ? 4L : ((paramObject instanceof safenet.jcprov.constants.CK_KEY_TYPE) ? 4L : ((paramObject instanceof safenet.jcprov.constants.CK_MECHANISM_TYPE) ? 4L : ((paramObject instanceof safenet.jcprov.constants.CK_OBJECT_CLASS) ? 4L : ((paramObject instanceof safenet.jcprov.constants.CK_RSA_PKCS_OAEP_SOURCE_TYPE) ? 4L : ((paramObject instanceof safenet.jcprov.constants.CK_STATE) ? 4L : ((paramObject instanceof safenet.jcprov.constants.CK_USER_TYPE) ? 4L : ((paramObject instanceof String) ? ((String)paramObject).length() : ((paramObject instanceof Boolean) ? 1L : ((paramObject instanceof long[]) ? ((long[])paramObject).length : ((paramObject instanceof int[]) ? ((int[])paramObject).length : ((paramObject instanceof char[]) ? ((char[])paramObject).length : ((paramObject instanceof boolean[]) ? ((boolean[])paramObject).length : ((paramObject instanceof Byte) ? 1L : ((paramObject instanceof Character) ? 1L : 0L)))))))))))))))))))))));
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/CK_ATTRIBUTE.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */