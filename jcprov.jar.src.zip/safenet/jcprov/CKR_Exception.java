package safenet.jcprov;

import safenet.jcprov.constants.CK_RV;

public class CKR_Exception extends RuntimeException {
  private static final long serialVersionUID = 1L;
  
  public String methodName;
  
  public CK_RV ckrv;
  
  public CKR_Exception(String paramString, CK_RV paramCK_RV) {
    super(paramString + " rv=0x" + Long.toHexString(paramCK_RV.longValue()) + " - " + errorString(paramCK_RV));
    this.ckrv = paramCK_RV;
    this.methodName = paramString;
  }
  
  public static String errorString(CK_RV paramCK_RV) {
    byte[] arrayOfByte = null;
    LongRef longRef = new LongRef();
    CTUtilEx.CTU_GetErrorString(paramCK_RV, arrayOfByte, longRef);
    arrayOfByte = new byte[(int)longRef.value];
    CTUtilEx.CTU_GetErrorString(paramCK_RV, arrayOfByte, longRef);
    return new String(arrayOfByte);
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/CKR_Exception.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */