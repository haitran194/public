package safenet.jcprov;

public class CK_VERSION {
  public byte major;
  
  public byte minor;
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/CK_VERSION.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */