package safenet.jcprov;

import safenet.jcprov.constants.CK_MECHANISM_TYPE;
import safenet.jcprov.constants.CK_RV;
import safenet.jcprov.constants.CK_USER_TYPE;

public class Cryptoki {
  public static native CK_RV C_Initialize(CK_C_INITIALIZE_ARGS paramCK_C_INITIALIZE_ARGS);
  
  public static native CK_RV C_Finalize(Object paramObject);
  
  public static native CK_RV C_GetInfo(CK_INFO paramCK_INFO);
  
  public static native CK_RV C_GetSlotList(CK_BBOOL paramCK_BBOOL, long[] paramArrayOflong, LongRef paramLongRef);
  
  public static native CK_RV C_GetSlotInfo(long paramLong, CK_SLOT_INFO paramCK_SLOT_INFO);
  
  public static native CK_RV C_GetTokenInfo(long paramLong, CK_TOKEN_INFO paramCK_TOKEN_INFO);
  
  public static native CK_RV C_GetMechanismList(long paramLong, CK_MECHANISM_TYPE[] paramArrayOfCK_MECHANISM_TYPE, LongRef paramLongRef);
  
  public static native CK_RV C_GetMechanismInfo(long paramLong, CK_MECHANISM_TYPE paramCK_MECHANISM_TYPE, CK_MECHANISM_INFO paramCK_MECHANISM_INFO);
  
  public static native CK_RV C_InitToken(long paramLong1, byte[] paramArrayOfbyte1, long paramLong2, byte[] paramArrayOfbyte2);
  
  public static native CK_RV C_InitPIN(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, long paramLong);
  
  public static native CK_RV C_SetPIN(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong1, byte[] paramArrayOfbyte2, long paramLong2);
  
  public static native CK_RV C_OpenSession(long paramLong1, long paramLong2, Object paramObject1, Object paramObject2, CK_SESSION_HANDLE paramCK_SESSION_HANDLE);
  
  public static native CK_RV C_CloseSession(CK_SESSION_HANDLE paramCK_SESSION_HANDLE);
  
  public static native CK_RV C_CloseAllSessions(long paramLong);
  
  public static native CK_RV C_GetSessionInfo(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_SESSION_INFO paramCK_SESSION_INFO);
  
  public static native CK_RV C_GetOperationState(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, LongRef paramLongRef);
  
  public static native CK_RV C_SetOperationState(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, long paramLong, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE1, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE2);
  
  public static native CK_RV C_Login(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_USER_TYPE paramCK_USER_TYPE, byte[] paramArrayOfbyte, long paramLong);
  
  public static native CK_RV C_Logout(CK_SESSION_HANDLE paramCK_SESSION_HANDLE);
  
  public static native CK_RV C_CreateObject(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE, long paramLong, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE);
  
  public static native CK_RV C_CopyObject(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE1, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE, long paramLong, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE2);
  
  public static native CK_RV C_DestroyObject(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE);
  
  public static native CK_RV C_GetObjectSize(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE, LongRef paramLongRef);
  
  public static native CK_RV C_GetAttributeValue(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE, long paramLong);
  
  public static native CK_RV C_SetAttributeValue(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE, long paramLong);
  
  public static native CK_RV C_FindObjectsInit(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE, long paramLong);
  
  public static native CK_RV C_FindObjects(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_OBJECT_HANDLE[] paramArrayOfCK_OBJECT_HANDLE, long paramLong, LongRef paramLongRef);
  
  public static native CK_RV C_FindObjectsFinal(CK_SESSION_HANDLE paramCK_SESSION_HANDLE);
  
  public static native CK_RV C_EncryptInit(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE);
  
  public static native CK_RV C_Encrypt(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef);
  
  public static native CK_RV C_EncryptUpdate(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef);
  
  public static native CK_RV C_EncryptFinal(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, LongRef paramLongRef);
  
  public static native CK_RV C_DecryptInit(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE);
  
  public static native CK_RV C_Decrypt(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef);
  
  public static native CK_RV C_DecryptUpdate(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef);
  
  public static native CK_RV C_DecryptFinal(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, LongRef paramLongRef);
  
  public static native CK_RV C_DigestInit(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM);
  
  public static native CK_RV C_Digest(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef);
  
  public static native CK_RV C_DigestUpdate(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, long paramLong);
  
  public static native CK_RV C_DigestKey(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE);
  
  public static native CK_RV C_DigestFinal(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, LongRef paramLongRef);
  
  public static native CK_RV C_SignInit(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE);
  
  public static native CK_RV C_Sign(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef);
  
  public static native CK_RV C_SignUpdate(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, long paramLong);
  
  public static native CK_RV C_SignFinal(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, LongRef paramLongRef);
  
  public static native CK_RV C_SignRecoverInit(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE);
  
  public static native CK_RV C_SignRecover(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef);
  
  public static native CK_RV C_VerifyInit(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE);
  
  public static native CK_RV C_Verify(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong1, byte[] paramArrayOfbyte2, long paramLong2);
  
  public static native CK_RV C_VerifyUpdate(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, long paramLong);
  
  public static native CK_RV C_VerifyFinal(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, long paramLong);
  
  public static native CK_RV C_VerifyRecoverInit(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE);
  
  public static native CK_RV C_VerifyRecover(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef);
  
  public static native CK_RV C_DigestEncryptUpdate(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef);
  
  public static native CK_RV C_DecryptDigestUpdate(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef);
  
  public static native CK_RV C_SignEncryptUpdate(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef);
  
  public static native CK_RV C_DecryptVerifyUpdate(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, LongRef paramLongRef);
  
  public static native CK_RV C_GenerateKey(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE, long paramLong, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE);
  
  public static native CK_RV C_GenerateKeyPair(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE1, long paramLong1, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE2, long paramLong2, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE1, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE2);
  
  public static native CK_RV C_WrapKey(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE1, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE2, byte[] paramArrayOfbyte, LongRef paramLongRef);
  
  public static native CK_RV C_UnwrapKey(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE1, byte[] paramArrayOfbyte, long paramLong1, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE, long paramLong2, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE2);
  
  public static native CK_RV C_DeriveKey(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_MECHANISM paramCK_MECHANISM, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE1, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE, long paramLong, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE2);
  
  public static native CK_RV C_SeedRandom(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, long paramLong);
  
  public static native CK_RV C_GenerateRandom(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte, long paramLong);
  
  public static native CK_RV C_GetFunctionStatus(CK_SESSION_HANDLE paramCK_SESSION_HANDLE);
  
  public static native CK_RV C_CancelFunction(CK_SESSION_HANDLE paramCK_SESSION_HANDLE);
  
  public static native CK_RV C_WaitForSlotEvent(long paramLong, LongRef paramLongRef, Object paramObject);
  
  public static native CK_RV CT_InitToken(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, long paramLong1, byte[] paramArrayOfbyte1, long paramLong2, byte[] paramArrayOfbyte2);
  
  public static native CK_RV CT_ResetToken(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2);
  
  public static native CK_RV CT_CopyObject(CK_SESSION_HANDLE paramCK_SESSION_HANDLE1, CK_SESSION_HANDLE paramCK_SESSION_HANDLE2, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE1, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE, long paramLong, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE2);
  
  public static native CK_RV FMSC_SendReceive(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, int paramInt, byte[] paramArrayOfbyte1, long paramLong1, byte[] paramArrayOfbyte2, long paramLong2, LongRef paramLongRef1, LongRef paramLongRef2);
  
  static {
    System.loadLibrary("jcprov");
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/Cryptoki.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */