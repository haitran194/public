package safenet.jcprov.constants;

public class CKD {
  public static final long NULL = 1L;
  
  public static final long SHA1_KDF = 2L;
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/constants/CKD.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */