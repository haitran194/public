package safenet.jcprov.constants;

public class CKR extends CK_RV {
  public static final CKR OK = new CKR(0L);
  
  public static final CKR CANCEL = new CKR(1L);
  
  public static final CKR HOST_MEMORY = new CKR(2L);
  
  public static final CKR SLOT_ID_INVALID = new CKR(3L);
  
  public static final CKR FLAGS_INVALID = new CKR(4L);
  
  public static final CKR GENERAL_ERROR = new CKR(5L);
  
  public static final CKR FUNCTION_FAILED = new CKR(6L);
  
  public static final CKR ARGUMENTS_BAD = new CKR(7L);
  
  public static final CKR NO_EVENT = new CKR(8L);
  
  public static final CKR NEED_TO_CREATE_THREADS = new CKR(9L);
  
  public static final CKR CANT_LOCK = new CKR(10L);
  
  public static final CKR ATTRIBUTE_READ_ONLY = new CKR(16L);
  
  public static final CKR ATTRIBUTE_SENSITIVE = new CKR(17L);
  
  public static final CKR ATTRIBUTE_TYPE_INVALID = new CKR(18L);
  
  public static final CKR ATTRIBUTE_VALUE_INVALID = new CKR(19L);
  
  public static final CKR DATA_INVALID = new CKR(32L);
  
  public static final CKR DATA_LEN_RANGE = new CKR(33L);
  
  public static final CKR DEVICE_ERROR = new CKR(48L);
  
  public static final CKR DEVICE_MEMORY = new CKR(49L);
  
  public static final CKR DEVICE_REMOVED = new CKR(50L);
  
  public static final CKR ENCRYPTED_DATA_INVALID = new CKR(64L);
  
  public static final CKR ENCRYPTED_DATA_LEN_RANGE = new CKR(65L);
  
  public static final CKR FUNCTION_CANCELED = new CKR(80L);
  
  public static final CKR FUNCTION_NOT_PARALLEL = new CKR(81L);
  
  public static final CKR FUNCTION_PARALLEL = new CKR(82L);
  
  public static final CKR FUNCTION_NOT_SUPPORTED = new CKR(84L);
  
  public static final CKR KEY_HANDLE_INVALID = new CKR(96L);
  
  public static final CKR KEY_SENSITIVE = new CKR(97L);
  
  public static final CKR KEY_SIZE_RANGE = new CKR(98L);
  
  public static final CKR KEY_TYPE_INCONSISTENT = new CKR(99L);
  
  public static final CKR KEY_NOT_NEEDED = new CKR(100L);
  
  public static final CKR KEY_CHANGED = new CKR(101L);
  
  public static final CKR KEY_NEEDED = new CKR(102L);
  
  public static final CKR KEY_INDIGESTABLE = new CKR(103L);
  
  public static final CKR KEY_FUNCTION_NOT_PERMITTED = new CKR(104L);
  
  public static final CKR KEY_NOT_WRAPPABLE = new CKR(105L);
  
  public static final CKR KEY_UNEXTRACTABLE = new CKR(106L);
  
  public static final CKR KEY_PARAMS_INVALID = new CKR(107L);
  
  public static final CKR MECHANISM_INVALID = new CKR(112L);
  
  public static final CKR MECHANISM_PARAM_INVALID = new CKR(113L);
  
  public static final CKR OBJECT_CLASS_INCONSISTENT = new CKR(128L);
  
  public static final CKR OBJECT_CLASS_INVALID = new CKR(129L);
  
  public static final CKR OBJECT_HANDLE_INVALID = new CKR(130L);
  
  public static final CKR OPERATION_ACTIVE = new CKR(144L);
  
  public static final CKR OPERATION_NOT_INITIALIZED = new CKR(145L);
  
  public static final CKR PIN_INCORRECT = new CKR(160L);
  
  public static final CKR PIN_INVALID = new CKR(161L);
  
  public static final CKR PIN_LEN_RANGE = new CKR(162L);
  
  public static final CKR PIN_EXPIRED = new CKR(163L);
  
  public static final CKR PIN_LOCKED = new CKR(164L);
  
  public static final CKR SESSION_CLOSED = new CKR(176L);
  
  public static final CKR SESSION_COUNT = new CKR(177L);
  
  public static final CKR SESSION_EXCLUSIVE_EXISTS = new CKR(178L);
  
  public static final CKR SESSION_HANDLE_INVALID = new CKR(179L);
  
  public static final CKR SESSION_PARALLEL_NOT_SUPPORTED = new CKR(180L);
  
  public static final CKR SESSION_READ_ONLY = new CKR(181L);
  
  public static final CKR SESSION_EXISTS = new CKR(182L);
  
  public static final CKR SESSION_READ_ONLY_EXISTS = new CKR(183L);
  
  public static final CKR SESSION_READ_WRITE_SO_EXISTS = new CKR(184L);
  
  public static final CKR SIGNATURE_INVALID = new CKR(192L);
  
  public static final CKR SIGNATURE_LEN_RANGE = new CKR(193L);
  
  public static final CKR TEMPLATE_INCOMPLETE = new CKR(208L);
  
  public static final CKR TEMPLATE_INCONSISTENT = new CKR(209L);
  
  public static final CKR TOKEN_NOT_PRESENT = new CKR(224L);
  
  public static final CKR TOKEN_NOT_RECOGNIZED = new CKR(225L);
  
  public static final CKR TOKEN_WRITE_PROTECTED = new CKR(226L);
  
  public static final CKR UNWRAPPING_KEY_HANDLE_INVALID = new CKR(240L);
  
  public static final CKR UNWRAPPING_KEY_TYPE_INCONSISTENT = new CKR(242L);
  
  public static final CKR UNWRAPPING_KEY_SIZE_RANGE = new CKR(241L);
  
  public static final CKR USER_ALREADY_LOGGED_IN = new CKR(256L);
  
  public static final CKR USER_NOT_LOGGED_IN = new CKR(257L);
  
  public static final CKR USER_PIN_NOT_INITIALIZED = new CKR(258L);
  
  public static final CKR USER_TYPE_INVALID = new CKR(259L);
  
  public static final CKR USER_ANOTHER_ALREADY_LOGGED_IN = new CKR(260L);
  
  public static final CKR USER_TOO_MANY_TYPES = new CKR(261L);
  
  public static final CKR WRAPPED_KEY_INVALID = new CKR(272L);
  
  public static final CKR WRAPPED_KEY_LEN_RANGE = new CKR(274L);
  
  public static final CKR WRAPPING_KEY_HANDLE_INVALID = new CKR(275L);
  
  public static final CKR WRAPPING_KEY_SIZE_RANGE = new CKR(276L);
  
  public static final CKR WRAPPING_KEY_TYPE_INCONSISTENT = new CKR(277L);
  
  public static final CKR CRYPTOKI_ALREADY_INITIALIZED = new CKR(401L);
  
  public static final CKR RANDOM_SEED_NOT_SUPPORTED = new CKR(288L);
  
  public static final CKR RANDOM_NO_RNG = new CKR(289L);
  
  public static final CKR DOMAIN_PARAMS_INVALID = new CKR(304L);
  
  public static final CKR BUFFER_TOO_SMALL = new CKR(336L);
  
  public static final CKR SAVED_STATE_INVALID = new CKR(352L);
  
  public static final CKR INFORMATION_SENSITIVE = new CKR(368L);
  
  public static final CKR STATE_UNSAVEABLE = new CKR(384L);
  
  public static final CKR CRYPTOKI_NOT_INITIALIZED = new CKR(400L);
  
  public static final CKR MUTEX_BAD = new CKR(416L);
  
  public static final CKR MUTEX_NOT_LOCKED = new CKR(417L);
  
  public static final CKR BIP32_CHILD_INDEX_INVALID = new CKR(2147483771L);
  
  public static final CKR BIP32_INVALID_HARDENED_DERIVATION = new CKR(2147483772L);
  
  public static final CKR BIP32_MASTER_SEED_LEN_INVALID = new CKR(2147483773L);
  
  public static final CKR BIP32_MASTER_SEED_INVALID = new CKR(2147483774L);
  
  public static final CKR BIP32_INVALID_KEY_PATH_LEN = new CKR(2147483775L);
  
  public static final CKR ERACOM_ERROR = new CKR(2147483904L);
  
  public static final CKR TIME_STAMP = new CKR(ERACOM_ERROR.longValue() + 1L);
  
  public static final CKR ACCESS_DENIED = new CKR(ERACOM_ERROR.longValue() + 2L);
  
  public static final CKR CRYPTOKI_UNUSABLE = new CKR(ERACOM_ERROR.longValue() + 3L);
  
  public static final CKR ENCODE_ERROR = new CKR(ERACOM_ERROR.longValue() + 4L);
  
  public static final CKR V_CONFIG = new CKR(ERACOM_ERROR.longValue() + 5L);
  
  public static final CKR SO_NOT_LOGGED_IN = new CKR(ERACOM_ERROR.longValue() + 6L);
  
  public static final CKR CERT_NOT_VALIDATED = new CKR(ERACOM_ERROR.longValue() + 7L);
  
  public static final CKR PIN_ALREADY_INITIALIZED = new CKR(ERACOM_ERROR.longValue() + 8L);
  
  public static final CKR REMOTE_SERVER_ERROR = new CKR(ERACOM_ERROR.longValue() + 10L);
  
  public static final CKR CSA_HW_ERROR = new CKR(ERACOM_ERROR.longValue() + 11L);
  
  public static final CKR NO_CHALLENGE = new CKR(ERACOM_ERROR.longValue() + 16L);
  
  public static final CKR RESPONSE_INVALID = new CKR(ERACOM_ERROR.longValue() + 17L);
  
  public static final CKR EVENT_LOG_NOT_FULL = new CKR(ERACOM_ERROR.longValue() + 19L);
  
  public static final CKR OBJECT_READ_ONLY = new CKR(ERACOM_ERROR.longValue() + 20L);
  
  public static final CKR TOKEN_READ_ONLY = new CKR(ERACOM_ERROR.longValue() + 21L);
  
  public static final CKR TOKEN_NOT_INITIALIZED = new CKR(ERACOM_ERROR.longValue() + 22L);
  
  public static final CKR NOT_ADMIN_TOKEN = new CKR(ERACOM_ERROR.longValue() + 23L);
  
  public static final CKR AUTHENTICATION_REQUIRED = new CKR(ERACOM_ERROR.longValue() + 48L);
  
  public static final CKR OPERATION_NOT_PERMITTED = new CKR(ERACOM_ERROR.longValue() + 49L);
  
  public static final CKR PKCS12_DECODE = new CKR(ERACOM_ERROR.longValue() + 50L);
  
  public static final CKR PKCS12_UNSUPPORTED_SAFEBAG_TYPE = new CKR(ERACOM_ERROR.longValue() + 51L);
  
  public static final CKR PKCS12_UNSUPPORTED_PRIVACY_MODE = new CKR(ERACOM_ERROR.longValue() + 52L);
  
  public static final CKR PKCS12_UNSUPPORTED_INTEGRITY_MODE = new CKR(ERACOM_ERROR.longValue() + 53L);
  
  public static final CKR KEY_NOT_ACTIVE = new CKR(ERACOM_ERROR.longValue() + 54L);
  
  public static final CKR ET_NOT_ODD_PARITY = new CKR(ERACOM_ERROR.longValue() + 64L);
  
  public static final CKR HOST_ERROR = new CKR(2147487744L);
  
  public static final CKR BAD_REQUEST = new CKR(HOST_ERROR.longValue() + 1L);
  
  public static final CKR BAD_ATTRIBUTE_PACKING = new CKR(HOST_ERROR.longValue() + 2L);
  
  public static final CKR BAD_ATTRIBUTE_COUNT = new CKR(HOST_ERROR.longValue() + 3L);
  
  public static final CKR BAD_PARAM_PACKING = new CKR(HOST_ERROR.longValue() + 4L);
  
  public static final CKR EXTERN_DCP_ERROR = new CKR(HOST_ERROR.longValue() + 902L);
  
  public static final CKR MSG_ERROR = new CKR(2147484416L);
  
  public static final CKR CANNOT_DERIVE_KEYS = new CKR(MSG_ERROR.longValue() + 129L);
  
  public static final CKR BAD_REQ_SIGNATURE = new CKR(MSG_ERROR.longValue() + 130L);
  
  public static final CKR BAD_REPLY_SIGNATURE = new CKR(MSG_ERROR.longValue() + 131L);
  
  public static final CKR SMS_ERROR = new CKR(MSG_ERROR.longValue() + 132L);
  
  public static final CKR BAD_PROTECTION = new CKR(MSG_ERROR.longValue() + 133L);
  
  public static final CKR DEVICE_RESET = new CKR(MSG_ERROR.longValue() + 134L);
  
  public static final CKR NO_SESSION_KEYS = new CKR(MSG_ERROR.longValue() + 135L);
  
  public static final CKR BAD_REPLY = new CKR(MSG_ERROR.longValue() + 136L);
  
  public static final CKR KEY_ROLLOVER = new CKR(MSG_ERROR.longValue() + 137L);
  
  public static final CKR NEED_IV_UPDATE = new CKR(MSG_ERROR.longValue() + 16L);
  
  public static final CKR DUPLICATE_IV_FOUND = new CKR(MSG_ERROR.longValue() + 17L);
  
  public static final CKR WLD_ERROR = new CKR(2147491840L);
  
  public static final CKR WLD_CONFIG_NOT_FOUND = new CKR(WLD_ERROR.longValue() + 1L);
  
  public static final CKR WLD_CONFIG_ITEM_READ_FAILED = new CKR(WLD_ERROR.longValue() + 2L);
  
  public static final CKR WLD_CONFIG_NO_TOKEN_LABEL = new CKR(WLD_ERROR.longValue() + 3L);
  
  public static final CKR WLD_CONFIG_TOKEN_LABEL_LEN = new CKR(WLD_ERROR.longValue() + 4L);
  
  public static final CKR WLD_CONFIG_TOKEN_SERIAL_NUM_LEN = new CKR(WLD_ERROR.longValue() + 5L);
  
  public static final CKR WLD_CONFIG_SLOT_DESCRIPTION_LEN = new CKR(WLD_ERROR.longValue() + 6L);
  
  public static final CKR WLD_CONFIG_ITEM_FORMAT_INVALID = new CKR(WLD_ERROR.longValue() + 7L);
  
  public static final CKR WLD_LOGIN_CACHE_INCONSISTENT = new CKR(WLD_ERROR.longValue() + 16L);
  
  public static final CKR HA_ERROR = new CKR(2147495936L);
  
  public static final CKR HA_MAX_SLOTS_INVALID_LEN = new CKR(HA_ERROR.longValue() + 1L);
  
  public static final CKR HA_SESSION_HANDLE_INVALID = new CKR(HA_ERROR.longValue() + 2L);
  
  public static final CKR HA_SESSION_INVALID = new CKR(HA_ERROR.longValue() + 3L);
  
  public static final CKR HA_OBJECT_INDEX_INVALID = new CKR(HA_ERROR.longValue() + 4L);
  
  public static final CKR HA_CANNOT_RECOVER_KEY = new CKR(HA_ERROR.longValue() + 5L);
  
  public static final CKR HA_NO_HSM = new CKR(HA_ERROR.longValue() + 6L);
  
  public static final CKR HA_OUT_OF_OBJS = new CKR(HA_ERROR.longValue() + 7L);
  
  public static final CKR SECURITY_FLAGS_INCOMPATIBLE = new CKR(2147497216L);
  
  public static final CKR FM_ERROR = new CKR(2147500032L);
  
  public static final CKR FM_NOT_REGISTERED = new CKR(FM_ERROR.longValue() + 1L);
  
  public static final CKR FM_DISPATCH_BLOCKED = new CKR(FM_ERROR.longValue() + 2L);
  
  public static final CKR OTP_PIN_INCORRECT = new CKR(2147483787L);
  
  public static final CKR OTP_PIN_LEN_RANGE = new CKR(2147483788L);
  
  public static final CKR OTP_PIN_ALREADY_INITIALIZED = new CKR(2147483789L);
  
  public static final CKR OTP_PIN_NOT_INITIALIZED = new CKR(2147483790L);
  
  public static final CKR OTP_PIN_REUSED = new CKR(2147483791L);
  
  public static final CKR POINT_INVALID = new CKR(2147483792L);
  
  public static final CKR IN_SOM = new CKR(2147483793L);
  
  public static final CKR TR31_HDR_INCONSISTENT = new CKR(2147483800L);
  
  public static final CKR INVALID_VALUE = new CKR(-1L);
  
  public void setValue(long paramLong) {
    throw new UnsupportedOperationException("Not allowed to modify a CKR constant");
  }
  
  private CKR(long paramLong) {
    super(paramLong);
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/constants/CKR.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */