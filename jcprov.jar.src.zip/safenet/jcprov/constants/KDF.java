package safenet.jcprov.constants;

public class KDF {
  public static final long CKD_NULL = 1L;
  
  public static final long CKD_SHA1_KDF = 2L;
  
  public static final long CKD_SHA224_KDF = -2147483645L;
  
  public static final long CKD_SHA256_KDF = -2147483644L;
  
  public static final long CKD_SHA384_KDF = -2147483643L;
  
  public static final long CKD_SHA512_KDF = -2147483642L;
  
  public static final long CKD_RIPEMD160_KDF = -2147483641L;
  
  public static final long CKD_SHA1_NIST_KDF = -2147483630L;
  
  public static final long CKD_SHA224_NIST_KDF = -2147483629L;
  
  public static final long CKD_SHA256_NIST_KDF = -2147483628L;
  
  public static final long CKD_SHA384_NIST_KDF = -2147483627L;
  
  public static final long CKD_SHA512_NIST_KDF = -2147483626L;
  
  public static final long CKD_RIPEMD160_NIST_KDF = -2147483625L;
  
  public static final long CKD_SHA1_SES_KDF = -2113929216L;
  
  public static final long CKD_SHA224_SES_KDF = -2097152000L;
  
  public static final long CKD_SHA256_SES_KDF = -2080374784L;
  
  public static final long CKD_SHA384_SES_KDF = -2063597568L;
  
  public static final long CKD_SHA512_SES_KDF = -2046820352L;
  
  public static final long CKD_RIPEMD160_SES_KDF = -2030043136L;
  
  public static final long CKD_SES_ENC_CTR = 1L;
  
  public static final long CKD_SES_AUTH_CTR = 2L;
  
  public static final long CKD_SES_ALT_ENC_CTR = 3L;
  
  public static final long CKD_SES_ALT_AUTH_CTR = 4L;
  
  public static final long CKD_SES_MAX_CTR = 65535L;
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/constants/KDF.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */