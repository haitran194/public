package safenet.jcprov.constants;

public class CK {
  public static final long MANUFACTURER_SIZE = 32L;
  
  public static final long SERIAL_NUMBER_SIZE = 16L;
  
  public static final long TIME_SIZE = 16L;
  
  public static final long LIB_DESC_SIZE = 32L;
  
  public static final long SLOT_DESCRIPTION_SIZE = 64L;
  
  public static final long SLOT_MANUFACTURER_SIZE = 32L;
  
  public static final long MAX_PIN_LEN = 32L;
  
  public static final long TOKEN_LABEL_SIZE = 32L;
  
  public static final long TOKEN_MANUFACTURER_SIZE = 32L;
  
  public static final long TOKEN_MODEL_SIZE = 16L;
  
  public static final long TOKEN_SERIAL_NUMBER_SIZE = 16L;
  
  public static final long TOKEN_TIME_SIZE = 16L;
  
  public static final long MAX_PBE_IV_SIZE = 8L;
  
  public static final long MAX_PAD_SIZE = 16L;
  
  public static final long VENDOR_DEFINED = 2147483648L;
  
  public static final long UNAVAILABLE_INFORMATION = GetConstantValue("UNAVAILABLE_INFORMATION");
  
  public static final long EFFECTIVELY_INFINITE = 0L;
  
  public static final long INVALID_HANDLE = 0L;
  
  public static final long NO_TRANSPORT_MODE = 0L;
  
  public static final long SINGLE_TRANSPORT_MODE = 1L;
  
  public static final long CONTINUOUS_TRANSPORT_MODE = 2L;
  
  public static final long EVENT_RECORD_LENGTH = 48L;
  
  public static final long MONOTONIC_COUNTER_SIZE = 20L;
  
  public static final long TIMESTAMP_FORMAT_ERACOM = 1L;
  
  static native long GetConstantValue(String paramString);
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/constants/CK.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */