package safenet.jcprov.constants;

public class CKH extends CK_HW_FEATURE_TYPE {
  public static final CKH MONOTONIC_COUNTER = new CKH(1L);
  
  public static final CKH CLOCK = new CKH(2L);
  
  public static final CKH EVENT_LOG = new CKH(2147483649L);
  
  public static final CKH INVALID_VALUE = new CKH(-1L);
  
  public void setValue(long paramLong) {
    throw new UnsupportedOperationException("Not allowed to modify a CKH constant");
  }
  
  private CKH(long paramLong) {
    super(paramLong);
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/constants/CKH.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */