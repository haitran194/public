package safenet.jcprov.constants;

public class CKK extends CK_KEY_TYPE {
  public static final CKK RSA = new CKK(0L);
  
  public static final CKK DSA = new CKK(1L);
  
  public static final CKK DH = new CKK(2L);
  
  public static final CKK ECDSA = new CKK(3L);
  
  public static final CKK EC = new CKK(3L);
  
  public static final CKK X9_42_DH = new CKK(4L);
  
  public static final CKK KEA = new CKK(5L);
  
  public static final CKK GENERIC_SECRET = new CKK(16L);
  
  public static final CKK RC2 = new CKK(17L);
  
  public static final CKK RC4 = new CKK(18L);
  
  public static final CKK RC5 = new CKK(25L);
  
  public static final CKK DES = new CKK(19L);
  
  public static final CKK DES2 = new CKK(20L);
  
  public static final CKK DES3 = new CKK(21L);
  
  public static final CKK CAST = new CKK(22L);
  
  public static final CKK CAST3 = new CKK(23L);
  
  public static final CKK CAST5 = new CKK(24L);
  
  public static final CKK CAST128 = new CKK(24L);
  
  public static final CKK IDEA = new CKK(26L);
  
  public static final CKK SKIPJACK = new CKK(27L);
  
  public static final CKK BATON = new CKK(28L);
  
  public static final CKK JUNIPER = new CKK(29L);
  
  public static final CKK CDMF = new CKK(30L);
  
  public static final CKK AES = new CKK(31L);
  
  public static final CKK ARIA = new CKK(38L);
  
  public static final CKK EC_EDWARDS = new CKK(64L);
  
  public static final CKK EC_MONTGOMERY = new CKK(65L);
  
  public static final CKK BIP32 = new CKK(2147483668L);
  
  public static final CKK RSA_DISCRETE = new CKK(2147484161L);
  
  public static final CKK DSA_DISCRETE = new CKK(2147484162L);
  
  public static final CKK INVALID_VALUE = new CKK(-1L);
  
  public static final CKK SEED = new CKK(2147484163L);
  
  public void setValue(long paramLong) {
    throw new UnsupportedOperationException("Not allowed to modify a CKK constant");
  }
  
  private CKK(long paramLong) {
    super(paramLong);
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/constants/CKK.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */