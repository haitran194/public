package safenet.jcprov.constants;

public class CKG {
  public static final long MGF1_SHA1 = 1L;
  
  public static final long MGF1_SHA224 = 5L;
  
  public static final long MGF1_SHA256 = 2L;
  
  public static final long MGF1_SHA384 = 3L;
  
  public static final long MGF1_SHA512 = 4L;
  
  public static final long BIP32_VERSION_MAINNET_PUB = 76067358L;
  
  public static final long BIP32_VERSION_MAINNET_PRIV = 76066276L;
  
  public static final long BIP32_VERSION_TESTNET_PUB = 70617039L;
  
  public static final long BIP32_VERSION_TESTNET_PRIV = 70615956L;
  
  public static final long BIP44_PURPOSE = 44L;
  
  public static final long BIP44_COIN_TYPE_BTC = 0L;
  
  public static final long BIP44_COIN_TYPE_BTC_TESTNET = 1L;
  
  public static final long BIP32_EXTERNAL_CHAIN = 0L;
  
  public static final long BIP32_INTERNAL_CHAIN = 1L;
  
  public static final long BIP32_MAX_SERIALIZED_LEN = 113L;
  
  public static final long BATTERY_LOW = 1L;
  
  public static final long PCB_VERSION = 14L;
  
  public static final long EXTERNAL_PINS = 240L;
  
  public static final long FPGA_VERSION = 3840L;
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/constants/CKG.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */