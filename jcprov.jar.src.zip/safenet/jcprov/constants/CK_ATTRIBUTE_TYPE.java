package safenet.jcprov.constants;

public class CK_ATTRIBUTE_TYPE {
  private long m_value = -1L;
  
  public CK_ATTRIBUTE_TYPE() {}
  
  public CK_ATTRIBUTE_TYPE(long paramLong) {}
  
  public long longValue() {
    return this.m_value;
  }
  
  public int intValue() {
    return (int)this.m_value;
  }
  
  public void setValue(long paramLong) {
    this.m_value = paramLong;
  }
  
  public boolean equals(Object paramObject) {
    return (paramObject != null && paramObject instanceof CK_ATTRIBUTE_TYPE && ((CK_ATTRIBUTE_TYPE)paramObject).longValue() == this.m_value);
  }
  
  public int hashCode() {
    return (int)this.m_value;
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/constants/CK_ATTRIBUTE_TYPE.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */