package safenet.jcprov.constants;

public class CKES {
  public static final long XOR = 1L;
  
  public static final long DES3_CBC_PAD = 2L;
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/constants/CKES.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */