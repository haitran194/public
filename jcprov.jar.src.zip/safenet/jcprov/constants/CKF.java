package safenet.jcprov.constants;

public class CKF {
  public static final long TOKEN_PRESENT = 1L;
  
  public static final long REMOVABLE_DEVICE = 2L;
  
  public static final long HW_SLOT = 4L;
  
  public static final long RNG = 1L;
  
  public static final long WRITE_PROTECTED = 2L;
  
  public static final long LOGIN_REQUIRED = 4L;
  
  public static final long USER_PIN_INITIALIZED = 8L;
  
  public static final long EXCLUSIVE_EXISTS = 16L;
  
  public static final long RESTORE_KEY_NOT_NEEDED = 32L;
  
  public static final long CLOCK_ON_TOKEN = 64L;
  
  public static final long PROTECTED_AUTHENTICATION_PATH = 256L;
  
  public static final long TOKEN_INITIALIZED = 1024L;
  
  public static final long DUAL_CRYPTO_OPERATIONS = 512L;
  
  public static final long SECONDARY_AUTHENTICATION = 2048L;
  
  public static final long USER_PIN_COUNT_LOW = 65536L;
  
  public static final long USER_PIN_FINAL_TRY = 131072L;
  
  public static final long USER_PIN_LOCKED = 262144L;
  
  public static final long USER_PIN_TO_BE_CHANGED = 524288L;
  
  public static final long SO_PIN_COUNT_LOW = 1048576L;
  
  public static final long SO_PIN_FINAL_TRY = 2097152L;
  
  public static final long SO_PIN_LOCKED = 4194304L;
  
  public static final long SO_PIN_TO_BE_CHANGED = 8388608L;
  
  public static final long EXCLUSIVE_SESSION = 1L;
  
  public static final long RW_SESSION = 2L;
  
  public static final long SERIAL_SESSION = 4L;
  
  public static final long HW = 1L;
  
  public static final long EXTENSION = 2147483648L;
  
  public static final long ENCRYPT = 256L;
  
  public static final long DECRYPT = 512L;
  
  public static final long DIGEST = 1024L;
  
  public static final long SIGN = 2048L;
  
  public static final long SIGN_RECOVER = 4096L;
  
  public static final long VERIFY = 8192L;
  
  public static final long VERIFY_RECOVER = 16384L;
  
  public static final long GENERATE = 32768L;
  
  public static final long GENERATE_KEY_PAIR = 65536L;
  
  public static final long WRAP = 131072L;
  
  public static final long UNWRAP = 262144L;
  
  public static final long DERIVE = 524288L;
  
  public static final long EC_F_P = 1048576L;
  
  public static final long EC_F_2M = 2097152L;
  
  public static final long EC_ECPARAMETERS = 4194304L;
  
  public static final long EC_NAMEDCURVE = 8388608L;
  
  public static final long EC_UNCOMPRESS = 16777216L;
  
  public static final long EC_COMPRESS = 33554432L;
  
  public static final long LIBRARY_CANT_CREATE_OS_THREADS = 1L;
  
  public static final long OS_LOCKING_OK = 2L;
  
  public static final long DONT_BLOCK = 1L;
  
  public static final long BIP32_HARDENED = 2147483648L;
  
  public static final long WLD_SLOT = 268435456L;
  
  public static final long ADMIN_TOKEN = 268435456L;
  
  public static final long WLD_TOKEN = 536870912L;
  
  public static final long WLD_SESSION = 268435456L;
  
  public static final long ENTRUST_READY = 1L;
  
  public static final long NO_CLEAR_PINS = 2L;
  
  public static final long AUTH_PROTECTION = 4L;
  
  public static final long NO_PUBLIC_CRYPTO = 8L;
  
  public static final long TAMPER_BEFORE_UPGRADE = 16L;
  
  public static final long INCREASED_SECURITY = 32L;
  
  public static final long FIPS_ALGORITHMS = 64L;
  
  public static final long FULL_SMS_ENC = 128L;
  
  public static final long FULL_SMS_SIGN = 256L;
  
  public static final long MODE_LOCKED = 268435456L;
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/constants/CKF.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */