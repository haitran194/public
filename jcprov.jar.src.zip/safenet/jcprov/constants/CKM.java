package safenet.jcprov.constants;

public class CKM extends CK_MECHANISM_TYPE {
  public static final CKM RSA_PKCS_KEY_PAIR_GEN = new CKM(0L);
  
  public static final CKM RSA_PKCS = new CKM(1L);
  
  public static final CKM RSA_9796 = new CKM(2L);
  
  public static final CKM RSA_X_509 = new CKM(3L);
  
  public static final CKM MD2_RSA_PKCS = new CKM(4L);
  
  public static final CKM MD5_RSA_PKCS = new CKM(5L);
  
  public static final CKM SHA1_RSA_PKCS = new CKM(6L);
  
  public static final CKM RIPEMD128_RSA_PKCS = new CKM(7L);
  
  public static final CKM RIPEMD160_RSA_PKCS = new CKM(8L);
  
  public static final CKM RSA_PKCS_OAEP = new CKM(9L);
  
  public static final CKM RSA_X9_31_KEY_PAIR_GEN = new CKM(10L);
  
  public static final CKM RSA_X9_31 = new CKM(11L);
  
  public static final CKM SHA1_RSA_X9_31 = new CKM(12L);
  
  public static final CKM RSA_PKCS_PSS = new CKM(13L);
  
  public static final CKM SHA1_RSA_PKCS_PSS = new CKM(14L);
  
  public static final CKM DSA_KEY_PAIR_GEN = new CKM(16L);
  
  public static final CKM DSA = new CKM(17L);
  
  public static final CKM DSA_SHA1 = new CKM(18L);
  
  public static final CKM DH_PKCS_KEY_PAIR_GEN = new CKM(32L);
  
  public static final CKM DH_PKCS_DERIVE = new CKM(33L);
  
  public static final CKM X9_42_DH_KEY_PAIR_GEN = new CKM(48L);
  
  public static final CKM X9_42_DH_DERIVE = new CKM(49L);
  
  public static final CKM X9_42_DH_HYBRID_DERIVE = new CKM(50L);
  
  public static final CKM X9_42_MQV_DERIVE = new CKM(51L);
  
  public static final CKM SHA256_RSA_PKCS = new CKM(64L);
  
  public static final CKM SHA384_RSA_PKCS = new CKM(65L);
  
  public static final CKM SHA512_RSA_PKCS = new CKM(66L);
  
  public static final CKM SHA256_RSA_PKCS_PSS = new CKM(67L);
  
  public static final CKM SHA384_RSA_PKCS_PSS = new CKM(68L);
  
  public static final CKM SHA512_RSA_PKCS_PSS = new CKM(69L);
  
  public static final CKM SHA224_RSA_PKCS = new CKM(70L);
  
  public static final CKM SHA224_RSA_PKCS_PSS = new CKM(71L);
  
  public static final CKM SHA3_256_RSA_PKCS = new CKM(96L);
  
  public static final CKM SHA3_384_RSA_PKCS = new CKM(97L);
  
  public static final CKM SHA3_512_RSA_PKCS = new CKM(98L);
  
  public static final CKM SHA3_256_RSA_PKCS_PSS = new CKM(99L);
  
  public static final CKM SHA3_384_RSA_PKCS_PSS = new CKM(100L);
  
  public static final CKM SHA3_512_RSA_PKCS_PSS = new CKM(101L);
  
  public static final CKM SHA3_224_RSA_PKCS = new CKM(102L);
  
  public static final CKM SHA3_224_RSA_PKCS_PSS = new CKM(103L);
  
  public static final CKM RC2_KEY_GEN = new CKM(256L);
  
  public static final CKM RC2_ECB = new CKM(257L);
  
  public static final CKM RC2_CBC = new CKM(258L);
  
  public static final CKM RC2_MAC = new CKM(259L);
  
  public static final CKM RC2_MAC_GENERAL = new CKM(260L);
  
  public static final CKM RC2_CBC_PAD = new CKM(261L);
  
  public static final CKM RC4_KEY_GEN = new CKM(272L);
  
  public static final CKM RC4 = new CKM(273L);
  
  public static final CKM DES_KEY_GEN = new CKM(288L);
  
  public static final CKM DES_ECB = new CKM(289L);
  
  public static final CKM DES_CBC = new CKM(290L, new byte[8]);
  
  public static final CKM DES_MAC = new CKM(291L);
  
  public static final CKM DES_MAC_GENERAL = new CKM(292L);
  
  public static final CKM DES_CBC_PAD = new CKM(293L, new byte[8]);
  
  public static final CKM DES2_KEY_GEN = new CKM(304L);
  
  public static final CKM DES3_KEY_GEN = new CKM(305L);
  
  public static final CKM DES3_ECB = new CKM(306L);
  
  public static final CKM DES3_CBC = new CKM(307L, new byte[8]);
  
  public static final CKM DES3_MAC = new CKM(308L);
  
  public static final CKM DES3_MAC_GENERAL = new CKM(309L);
  
  public static final CKM DES3_CBC_PAD = new CKM(310L, new byte[8]);
  
  public static final CKM DES3_CMAC_GENERAL = new CKM(311L);
  
  public static final CKM DES3_CMAC = new CKM(312L);
  
  public static final CKM CDMF_KEY_GEN = new CKM(320L);
  
  public static final CKM CDMF_ECB = new CKM(321L);
  
  public static final CKM CDMF_CBC = new CKM(322L);
  
  public static final CKM CDMF_MAC = new CKM(323L);
  
  public static final CKM CDMF_MAC_GENERAL = new CKM(324L);
  
  public static final CKM CDMF_CBC_PAD = new CKM(325L);
  
  public static final CKM MD2 = new CKM(512L);
  
  public static final CKM MD2_HMAC = new CKM(513L);
  
  public static final CKM MD2_HMAC_GENERAL = new CKM(514L);
  
  public static final CKM MD5 = new CKM(528L);
  
  public static final CKM MD5_HMAC = new CKM(529L);
  
  public static final CKM MD5_HMAC_GENERAL = new CKM(530L);
  
  public static final CKM SHA_1 = new CKM(544L);
  
  public static final CKM SHA_1_HMAC = new CKM(545L);
  
  public static final CKM SHA_1_HMAC_GENERAL = new CKM(546L);
  
  public static final CKM RIPEMD128 = new CKM(560L);
  
  public static final CKM RIPEMD128_HMAC = new CKM(561L);
  
  public static final CKM RIPEMD128_HMAC_GENERAL = new CKM(562L);
  
  public static final CKM RIPEMD160 = new CKM(576L);
  
  public static final CKM RIPEMD160_HMAC = new CKM(577L);
  
  public static final CKM RIPEMD160_HMAC_GENERAL = new CKM(578L);
  
  public static final CKM SHA256 = new CKM(592L);
  
  public static final CKM SHA256_HMAC = new CKM(593L);
  
  public static final CKM SHA256_HMAC_GENERAL = new CKM(594L);
  
  public static final CKM SHA224 = new CKM(597L);
  
  public static final CKM SHA224_HMAC = new CKM(598L);
  
  public static final CKM SHA224_HMAC_GENERAL = new CKM(599L);
  
  public static final CKM SHA384 = new CKM(608L);
  
  public static final CKM SHA384_HMAC = new CKM(609L);
  
  public static final CKM SHA384_HMAC_GENERAL = new CKM(610L);
  
  public static final CKM SHA512 = new CKM(624L);
  
  public static final CKM SHA512_HMAC = new CKM(625L);
  
  public static final CKM SHA512_HMAC_GENERAL = new CKM(626L);
  
  public static final CKM SHA3_256 = new CKM(688L);
  
  public static final CKM SHA3_256_HMAC = new CKM(689L);
  
  public static final CKM SHA3_256_HMAC_GENERAL = new CKM(690L);
  
  public static final CKM SHA3_224 = new CKM(693L);
  
  public static final CKM SHA3_224_HMAC = new CKM(694L);
  
  public static final CKM SHA3_224_HMAC_GENERAL = new CKM(695L);
  
  public static final CKM SHA3_384 = new CKM(704L);
  
  public static final CKM SHA3_384_HMAC = new CKM(705L);
  
  public static final CKM SHA3_384_HMAC_GENERAL = new CKM(706L);
  
  public static final CKM SHA3_512 = new CKM(720L);
  
  public static final CKM SHA3_512_HMAC = new CKM(721L);
  
  public static final CKM SHA3_512_HMAC_GENERAL = new CKM(722L);
  
  public static final CKM CAST_KEY_GEN = new CKM(768L);
  
  public static final CKM CAST_ECB = new CKM(769L);
  
  public static final CKM CAST_CBC = new CKM(770L);
  
  public static final CKM CAST_MAC = new CKM(771L);
  
  public static final CKM CAST_MAC_GENERAL = new CKM(772L);
  
  public static final CKM CAST_CBC_PAD = new CKM(773L);
  
  public static final CKM CAST3_KEY_GEN = new CKM(784L);
  
  public static final CKM CAST3_ECB = new CKM(785L);
  
  public static final CKM CAST3_CBC = new CKM(786L);
  
  public static final CKM CAST3_MAC = new CKM(787L);
  
  public static final CKM CAST3_MAC_GENERAL = new CKM(788L);
  
  public static final CKM CAST3_CBC_PAD = new CKM(789L);
  
  public static final CKM CAST5_KEY_GEN = new CKM(800L);
  
  public static final CKM CAST5_ECB = new CKM(801L);
  
  public static final CKM CAST5_CBC = new CKM(802L, new byte[8]);
  
  public static final CKM CAST5_MAC = new CKM(803L);
  
  public static final CKM CAST5_MAC_GENERAL = new CKM(804L);
  
  public static final CKM CAST5_CBC_PAD = new CKM(805L, new byte[8]);
  
  public static final CKM CAST128_KEY_GEN = new CKM(800L);
  
  public static final CKM CAST128_ECB = new CKM(801L);
  
  public static final CKM CAST128_CBC = new CKM(802L, new byte[8]);
  
  public static final CKM CAST128_MAC = new CKM(803L);
  
  public static final CKM CAST128_MAC_GENERAL = new CKM(804L);
  
  public static final CKM CAST128_CBC_PAD = new CKM(805L, new byte[8]);
  
  public static final CKM RC5_KEY_GEN = new CKM(816L);
  
  public static final CKM RC5_ECB = new CKM(817L);
  
  public static final CKM RC5_CBC = new CKM(818L);
  
  public static final CKM RC5_MAC = new CKM(819L);
  
  public static final CKM RC5_MAC_GENERAL = new CKM(820L);
  
  public static final CKM RC5_CBC_PAD = new CKM(821L);
  
  public static final CKM IDEA_KEY_GEN = new CKM(832L);
  
  public static final CKM IDEA_ECB = new CKM(833L);
  
  public static final CKM IDEA_CBC = new CKM(834L, new byte[8]);
  
  public static final CKM IDEA_MAC = new CKM(835L);
  
  public static final CKM IDEA_MAC_GENERAL = new CKM(836L);
  
  public static final CKM IDEA_CBC_PAD = new CKM(837L, new byte[8]);
  
  public static final CKM GENERIC_SECRET_KEY_GEN = new CKM(848L);
  
  public static final CKM CONCATENATE_BASE_AND_KEY = new CKM(864L);
  
  public static final CKM CONCATENATE_BASE_AND_DATA = new CKM(866L);
  
  public static final CKM CONCATENATE_DATA_AND_BASE = new CKM(867L);
  
  public static final CKM XOR_BASE_AND_DATA = new CKM(868L);
  
  public static final CKM EXTRACT_KEY_FROM_KEY = new CKM(869L);
  
  public static final CKM SSL3_PRE_MASTER_KEY_GEN = new CKM(880L);
  
  public static final CKM SSL3_MASTER_KEY_DERIVE = new CKM(881L);
  
  public static final CKM SSL3_KEY_AND_MAC_DERIVE = new CKM(882L);
  
  public static final CKM SSL3_MASTER_KEY_DERIVE_DH = new CKM(883L);
  
  public static final CKM TLS_PRE_MASTER_KEY_GEN = new CKM(884L);
  
  public static final CKM TLS_MASTER_KEY_DERIVE = new CKM(885L);
  
  public static final CKM TLS_KEY_AND_MAC_DERIVE = new CKM(886L);
  
  public static final CKM TLS_MASTER_KEY_DERIVE_DH = new CKM(887L);
  
  public static final CKM SSL3_MD5_MAC = new CKM(896L);
  
  public static final CKM SSL3_SHA1_MAC = new CKM(897L);
  
  public static final CKM MD5_KEY_DERIVATION = new CKM(912L);
  
  public static final CKM MD2_KEY_DERIVATION = new CKM(913L);
  
  public static final CKM SHA1_KEY_DERIVATION = new CKM(914L);
  
  public static final CKM SHA224_KEY_DERIVATION = new CKM(918L);
  
  public static final CKM SHA256_KEY_DERIVATION = new CKM(915L);
  
  public static final CKM SHA384_KEY_DERIVATION = new CKM(916L);
  
  public static final CKM SHA512_KEY_DERIVATION = new CKM(917L);
  
  public static final CKM SHA3_224_KEY_DERIVE = new CKM(919L);
  
  public static final CKM SHA3_256_KEY_DERIVE = new CKM(920L);
  
  public static final CKM SHA3_384_KEY_DERIVE = new CKM(921L);
  
  public static final CKM SHA3_512_KEY_DERIVE = new CKM(922L);
  
  public static final CKM PBE_MD2_DES_CBC = new CKM(928L);
  
  public static final CKM PBE_MD5_DES_CBC = new CKM(929L);
  
  public static final CKM PBE_MD5_CAST_CBC = new CKM(930L);
  
  public static final CKM PBE_MD5_CAST3_CBC = new CKM(931L);
  
  public static final CKM PBE_MD5_CAST5_CBC = new CKM(932L);
  
  public static final CKM PBE_MD5_CAST128_CBC = new CKM(932L);
  
  public static final CKM PBE_SHA1_CAST5_CBC = new CKM(933L);
  
  public static final CKM PBE_SHA1_CAST128_CBC = new CKM(933L);
  
  public static final CKM PBE_SHA1_RC4_128 = new CKM(934L);
  
  public static final CKM PBE_SHA1_RC4_40 = new CKM(935L);
  
  public static final CKM PBE_SHA1_DES3_EDE_CBC = new CKM(936L);
  
  public static final CKM PBE_SHA1_DES2_EDE_CBC = new CKM(937L);
  
  public static final CKM PBE_SHA1_RC2_128_CBC = new CKM(938L);
  
  public static final CKM PBE_SHA1_RC2_40_CBC = new CKM(939L);
  
  public static final CKM PKCS5_PBKD2 = new CKM(944L);
  
  public static final CKM PBA_SHA1_WITH_SHA1_HMAC = new CKM(960L);
  
  public static final CKM KEY_WRAP_LYNKS = new CKM(1024L);
  
  public static final CKM KEY_WRAP_SET_OAEP = new CKM(1025L);
  
  public static final CKM SKIPJACK_KEY_GEN = new CKM(4096L);
  
  public static final CKM SKIPJACK_ECB64 = new CKM(4097L);
  
  public static final CKM SKIPJACK_CBC64 = new CKM(4098L);
  
  public static final CKM SKIPJACK_OFB64 = new CKM(4099L);
  
  public static final CKM SKIPJACK_CFB64 = new CKM(4100L);
  
  public static final CKM SKIPJACK_CFB32 = new CKM(4101L);
  
  public static final CKM SKIPJACK_CFB16 = new CKM(4102L);
  
  public static final CKM SKIPJACK_CFB8 = new CKM(4103L);
  
  public static final CKM SKIPJACK_WRAP = new CKM(4104L);
  
  public static final CKM SKIPJACK_PRIVATE_WRAP = new CKM(4105L);
  
  public static final CKM SKIPJACK_RELAYX = new CKM(4106L);
  
  public static final CKM KEA_KEY_PAIR_GEN = new CKM(4112L);
  
  public static final CKM KEA_KEY_DERIVE = new CKM(4113L);
  
  public static final CKM FORTEZZA_TIMESTAMP = new CKM(4128L);
  
  public static final CKM BATON_KEY_GEN = new CKM(4144L);
  
  public static final CKM BATON_ECB128 = new CKM(4145L);
  
  public static final CKM BATON_ECB96 = new CKM(4146L);
  
  public static final CKM BATON_CBC128 = new CKM(4147L);
  
  public static final CKM BATON_COUNTER = new CKM(4148L);
  
  public static final CKM BATON_SHUFFLE = new CKM(4149L);
  
  public static final CKM BATON_WRAP = new CKM(4150L);
  
  public static final CKM ECDSA_KEY_PAIR_GEN = new CKM(4160L);
  
  public static final CKM EC_KEY_PAIR_GEN = new CKM(4160L);
  
  public static final CKM ECDSA = new CKM(4161L);
  
  public static final CKM ECDSA_SHA1 = new CKM(4162L);
  
  public static final CKM ECDSA_SHA224 = new CKM(2147483938L);
  
  public static final CKM ECDSA_SHA256 = new CKM(2147483939L);
  
  public static final CKM ECDSA_SHA384 = new CKM(2147483940L);
  
  public static final CKM ECDSA_SHA512 = new CKM(2147483941L);
  
  public static final CKM ECDSA_SHA3_224 = new CKM(4167L);
  
  public static final CKM ECDSA_SHA3_256 = new CKM(4168L);
  
  public static final CKM ECDSA_SHA3_384 = new CKM(4169L);
  
  public static final CKM ECDSA_SHA3_512 = new CKM(4170L);
  
  public static final CKM ECDH1_COFACTOR_DERIVE = new CKM(4164L);
  
  public static final CKM ECMQV_DERIVE = new CKM(4165L);
  
  public static final CKM EC_EDWARDS_KEY_PAIR_GEN = new CKM(4181L);
  
  public static final CKM EC_MONTGOMERY_KEY_PAIR_GEN = new CKM(4182L);
  
  public static final CKM EDDSA = new CKM(4183L);
  
  public static final CKM JUNIPER_KEY_GEN = new CKM(4192L);
  
  public static final CKM JUNIPER_ECB128 = new CKM(4193L);
  
  public static final CKM JUNIPER_CBC128 = new CKM(4194L);
  
  public static final CKM JUNIPER_COUNTER = new CKM(4195L);
  
  public static final CKM JUNIPER_SHUFFLE = new CKM(4196L);
  
  public static final CKM JUNIPER_WRAP = new CKM(4197L);
  
  public static final CKM FASTHASH = new CKM(4208L);
  
  public static final CKM AES_KEY_GEN = new CKM(4224L);
  
  public static final CKM AES_ECB = new CKM(4225L);
  
  public static final CKM AES_CBC = new CKM(4226L, new byte[16]);
  
  public static final CKM AES_MAC = new CKM(4227L);
  
  public static final CKM AES_MAC_GENERAL = new CKM(4228L);
  
  public static final CKM AES_CBC_PAD = new CKM(4229L, new byte[16]);
  
  public static final CKM AES_GCM = new CKM(4231L);
  
  public static final CKM AES_CCM = new CKM(4232L);
  
  public static final CKM AES_CTR = new CKM(4230L);
  
  public static final CKM AES_CMAC = new CKM(4234L);
  
  public static final CKM AES_CMAC_GENERAL = new CKM(4235L);
  
  public static final CKM AES_GMAC = new CKM(4238L);
  
  public static final CKM DES_ECB_ENCRYPT_DATA = new CKM(4352L);
  
  public static final CKM DES_CBC_ENCRYPT_DATA = new CKM(4353L);
  
  public static final CKM DES3_ECB_ENCRYPT_DATA = new CKM(4354L);
  
  public static final CKM DES3_CBC_ENCRYPT_DATA = new CKM(4355L);
  
  public static final CKM AES_ECB_ENCRYPT_DATA = new CKM(4356L);
  
  public static final CKM AES_CBC_ENCRYPT_DATA = new CKM(4357L);
  
  public static final CKM DSA_PARAMETER_GEN = new CKM(8192L);
  
  public static final CKM DH_PKCS_PARAMETER_GEN = new CKM(8193L);
  
  public static final CKM X9_42_DH_PARAMETER_GEN = new CKM(8194L);
  
  public static final CKM BIP32_MASTER_DERIVE = new CKM(2147487232L);
  
  public static final CKM BIP32_CHILD_DERIVE = new CKM(2147487233L);
  
  public static final CKM VENDOR_DEFINED = new CKM(2147483648L);
  
  public static final CKM AES_KW = new CKM(2147484016L);
  
  public static final CKM AES_KWP = new CKM(2147484017L);
  
  public static final CKM TDEA_TKW = new CKM(2147484018L);
  
  public static final CKM DSA_SHA1_PKCS = new CKM(2147483648L + DSA_SHA1.longValue() + 1L);
  
  public static final CKM DES_MDC_2_PAD1 = new CKM(2147484160L);
  
  public static final CKM ARDFP = new CKM(2147484164L);
  
  public static final CKM NVB = new CKM(2147484165L);
  
  public static final CKM UNWRAP_TR31_DISCARD = new CKM(2147484688L);
  
  public static final CKM UNWRAP_TR31 = new CKM(2147484689L);
  
  public static final CKM WRAP_TR31_DERIVE = new CKM(2147484690L);
  
  public static final CKM WRAP_TR31_VARIANT = new CKM(2147484691L);
  
  public static final CKM WRAP_TR31_DERIVE_CTR = new CKM(2147484692L);
  
  public static final CKM DES_ECB_PAD = new CKM(2147483648L + DES_ECB.longValue());
  
  public static final CKM CAST5_ECB_PAD = new CKM(2147483648L + CAST5_ECB.longValue());
  
  public static final CKM CAST128_ECB_PAD = new CKM(CAST5_ECB_PAD.longValue());
  
  public static final CKM DES3_ECB_PAD = new CKM(2147483648L + DES3_ECB.longValue());
  
  public static final CKM IDEA_ECB_PAD = new CKM(2147483648L + IDEA_ECB.longValue());
  
  public static final CKM RC2_ECB_PAD = new CKM(2147483648L + RC2_ECB.longValue());
  
  public static final CKM DES_DERIVE_ECB = new CKM(2147484928L);
  
  public static final CKM DES_DERIVE_CBC = new CKM(2147484929L);
  
  public static final CKM DES3_DERIVE_ECB = new CKM(2147484930L);
  
  public static final CKM DES3_DERIVE_CBC = new CKM(2147484931L);
  
  public static final CKM DES3_RETAIL_CFB_MAC = new CKM(2147484944L);
  
  public static final CKM SHA1_RSA_PKCS_TIMESTAMP = new CKM(2147485184L);
  
  public static final CKM DES_BCFv = new CKM(2147484558L);
  
  public static final CKM DES3_BCF = new CKM(2147484559L);
  
  public static final CKM DES3_X919_MAC = new CKM(2147483648L + DES3_MAC.longValue(), new byte[8]);
  
  public static final CKM DES3_X919_MAC_GENERAL = new CKM(2147483648L + DES3_MAC_GENERAL.longValue());
  
  public static final CKM DECODE_PKCS_7 = new CKM(2147486005L);
  
  public static final CKM DES_OFB64 = new CKM(2147486016L, new byte[8]);
  
  public static final CKM DES3_OFB64 = new CKM(2147486017L, new byte[8]);
  
  public static final CKM XOR_BASE_AND_KEY = new CKM(2147484516L);
  
  public static final CKM ENCODE_ATTRIBUTES = new CKM(2147486032L);
  
  public static final CKM ENCODE_X_509 = new CKM(2147486033L);
  
  public static final CKM ENCODE_PKCS_10 = new CKM(2147486034L);
  
  public static final CKM DECODE_X_509 = new CKM(2147486035L);
  
  public static final CKM ENCODE_PUBLIC_KEY = new CKM(2147486036L);
  
  public static final CKM ENCODE_X_509_LOCAL_CERT = new CKM(2147486037L);
  
  public static final CKM WRAPKEY_DES3_ECB = new CKM(2147486049L);
  
  public static final CKM WRAPKEY_DES3_CBC = new CKM(2147486050L);
  
  public static final CKM DES3_DDD_CBC = new CKM(2147486052L, new byte[8]);
  
  public static final CKM KEY_TRANSLATION = new CKM(2147483675L);
  
  public static final CKM OS_UPGRADE = new CKM(2147486096L);
  
  public static final CKM FM_DOWNLOAD = new CKM(2147486097L);
  
  public static final CKM PP_LOAD_SECRET = new CKM(2147486112L);
  
  public static final CKM VISA_CVV = new CKM(2147486128L);
  
  public static final CKM ZKA_MDC_2_KEY_DERIVATION = new CKM(2147486144L, null);
  
  public static final CKM SEED_KEY_GEN = new CKM(2147486160L);
  
  public static final CKM SEED_ECB = new CKM(2147486161L);
  
  public static final CKM SEED_CBC = new CKM(2147486162L, new byte[16]);
  
  public static final CKM SEED_MAC = new CKM(2147486163L);
  
  public static final CKM SEED_MAC_GENERAL = new CKM(2147486164L);
  
  public static final CKM SEED_ECB_PAD = new CKM(2147486165L);
  
  public static final CKM SEED_CBC_PAD = new CKM(2147486166L, new byte[16]);
  
  public static final CKM REPLICATE_TOKEN_RSA_AES = new CKM(2147486176L);
  
  public static final CKM SECRET_SHARE_WITH_ATTRIBUTES = new CKM(2147486192L);
  
  public static final CKM SECRET_RECOVER_WITH_ATTRIBUTES = new CKM(2147486193L);
  
  public static final CKM PKCS12_PBE_EXPORT = new CKM(2147486194L);
  
  public static final CKM PKCS12_PBE_IMPORT = new CKM(2147486195L);
  
  public static final CKM ECIES = new CKM(2147486208L);
  
  public static final CKM ECDH1_DERIVE = new CKM(4176L);
  
  public static final CKM GEN_PIK_ECC_P521 = new CKM(2147487744L);
  
  public static final CKM GEN_KTK_ECC_P521 = new CKM(2147487745L);
  
  public static final CKM GEN_KDE_ECC_P521_DERIVE_SEND = new CKM(2147487746L);
  
  public static final CKM GEN_KDE_ECC_P521_DERIVE_RECV = new CKM(2147487747L);
  
  public static final CKM TOKEN_WRAP_KTK_ECC_P521 = new CKM(2147487748L);
  
  public static final CKM INVALID_VALUE = new CKM(-1L);
  
  public void setValue(long paramLong) {
    throw new UnsupportedOperationException("Not allowed to modify a CKM constant");
  }
  
  private CKM(long paramLong) {
    super(paramLong);
  }
  
  private CKM(long paramLong, Object paramObject) {
    super(paramLong, paramObject);
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/constants/CKM.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */