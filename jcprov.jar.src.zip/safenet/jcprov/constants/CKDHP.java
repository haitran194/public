package safenet.jcprov.constants;

public class CKDHP {
  public static final long STANDARD = 1L;
  
  public static final long MODIFIED = 2L;
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/constants/CKDHP.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */