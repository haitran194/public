package safenet.jcprov.constants;

public class CKC extends CK_CERTIFICATE_TYPE {
  public static final CKC X_509 = new CKC(0L);
  
  public static final CKC X_509_ATTR_CERT = new CKC(1L);
  
  public static final CKC INVALID_VALUE = new CKC(-1L);
  
  public void setValue(long paramLong) {
    throw new UnsupportedOperationException("Not allowed to modify a CKC constant");
  }
  
  private CKC(long paramLong) {
    super(paramLong);
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/constants/CKC.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */