package safenet.jcprov.constants;

public class CKU extends CK_USER_TYPE {
  public static final CKU SO = new CKU(0L);
  
  public static final CKU USER = new CKU(1L);
  
  public static final CKU INVALID_VALUE = new CKU(-1L);
  
  public void setValue(long paramLong) {
    throw new UnsupportedOperationException("Not allowed to modify a CKU constant");
  }
  
  private CKU(long paramLong) {
    super(paramLong);
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/constants/CKU.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */