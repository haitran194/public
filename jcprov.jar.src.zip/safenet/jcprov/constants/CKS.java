package safenet.jcprov.constants;

public class CKS extends CK_STATE {
  public static final CKS RO_PUBLIC_SESSION = new CKS(0L);
  
  public static final CKS RO_USER_FUNCTIONS = new CKS(1L);
  
  public static final CKS RW_PUBLIC_SESSION = new CKS(2L);
  
  public static final CKS RW_USER_FUNCTIONS = new CKS(3L);
  
  public static final CKS RW_SO_FUNCTIONS = new CKS(4L);
  
  public static final CKS INVALID_VALUE = new CKS(-1L);
  
  public void setValue(long paramLong) {
    throw new UnsupportedOperationException("Not allowed to modify a CKS constant");
  }
  
  private CKS(long paramLong) {
    super(paramLong);
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/constants/CKS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */