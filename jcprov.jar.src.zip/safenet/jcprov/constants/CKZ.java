package safenet.jcprov.constants;

public class CKZ extends CK_RSA_PKCS_OAEP_SOURCE_TYPE {
  public static final CKZ DATA_SPECIFIED = new CKZ(1L);
  
  public static final CKZ INVALID_VALUE = new CKZ(-1L);
  
  public void setValue(long paramLong) {
    throw new UnsupportedOperationException("Not allowed to modify a CKZ constant");
  }
  
  private CKZ(long paramLong) {
    super(paramLong);
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/constants/CKZ.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */