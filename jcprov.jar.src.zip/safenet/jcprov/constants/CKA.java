package safenet.jcprov.constants;

public class CKA extends CK_ATTRIBUTE_TYPE {
  public static final CKA CLASS = new CKA(0L);
  
  public static final CKA TOKEN = new CKA(1L);
  
  public static final CKA PRIVATE = new CKA(2L);
  
  public static final CKA LABEL = new CKA(3L);
  
  public static final CKA APPLICATION = new CKA(16L);
  
  public static final CKA VALUE = new CKA(17L);
  
  public static final CKA OBJECT_ID = new CKA(18L);
  
  public static final CKA CERTIFICATE_TYPE = new CKA(128L);
  
  public static final CKA ISSUER = new CKA(129L);
  
  public static final CKA SERIAL_NUMBER = new CKA(130L);
  
  public static final CKA AC_ISSUER = new CKA(131L);
  
  public static final CKA OWNER = new CKA(132L);
  
  public static final CKA ATTR_TYPES = new CKA(133L);
  
  public static final CKA TRUSTED = new CKA(134L);
  
  public static final CKA CHECK_VALUE = new CKA(144L);
  
  public static final CKA KEY_TYPE = new CKA(256L);
  
  public static final CKA SUBJECT = new CKA(257L);
  
  public static final CKA ID = new CKA(258L);
  
  public static final CKA SENSITIVE = new CKA(259L);
  
  public static final CKA ENCRYPT = new CKA(260L);
  
  public static final CKA DECRYPT = new CKA(261L);
  
  public static final CKA WRAP = new CKA(262L);
  
  public static final CKA UNWRAP = new CKA(263L);
  
  public static final CKA SIGN = new CKA(264L);
  
  public static final CKA SIGN_RECOVER = new CKA(265L);
  
  public static final CKA VERIFY = new CKA(266L);
  
  public static final CKA VERIFY_RECOVER = new CKA(267L);
  
  public static final CKA DERIVE = new CKA(268L);
  
  public static final CKA START_DATE = new CKA(272L);
  
  public static final CKA END_DATE = new CKA(273L);
  
  public static final CKA MODULUS = new CKA(288L);
  
  public static final CKA MODULUS_BITS = new CKA(289L);
  
  public static final CKA PUBLIC_EXPONENT = new CKA(290L);
  
  public static final CKA PRIVATE_EXPONENT = new CKA(291L);
  
  public static final CKA PRIME_1 = new CKA(292L);
  
  public static final CKA PRIME_2 = new CKA(293L);
  
  public static final CKA EXPONENT_1 = new CKA(294L);
  
  public static final CKA EXPONENT_2 = new CKA(295L);
  
  public static final CKA COEFFICIENT = new CKA(296L);
  
  public static final CKA PRIME = new CKA(304L);
  
  public static final CKA SUBPRIME = new CKA(305L);
  
  public static final CKA BASE = new CKA(306L);
  
  public static final CKA PRIME_BITS = new CKA(307L);
  
  public static final CKA SUB_PRIME_BITS = new CKA(308L);
  
  public static final CKA VALUE_BITS = new CKA(352L);
  
  public static final CKA VALUE_LEN = new CKA(353L);
  
  public static final CKA EXTRACTABLE = new CKA(354L);
  
  public static final CKA LOCAL = new CKA(355L);
  
  public static final CKA NEVER_EXTRACTABLE = new CKA(356L);
  
  public static final CKA ALWAYS_SENSITIVE = new CKA(357L);
  
  public static final CKA MODIFIABLE = new CKA(368L);
  
  public static final CKA ECDSA_PARAMS = new CKA(384L);
  
  public static final CKA EC_PARAMS = new CKA(384L);
  
  public static final CKA EC_POINT = new CKA(385L);
  
  public static final CKA SECONDARY_AUTH = new CKA(512L);
  
  public static final CKA AUTH_PIN_FLAGS = new CKA(513L);
  
  public static final CKA HW_FEATURE_TYPE = new CKA(768L);
  
  public static final CKA RESET_ON_INIT = new CKA(769L);
  
  public static final CKA HAS_RESET = new CKA(770L);
  
  public static final CKA BIP32_CHAIN_CODE = new CKA(2147488000L);
  
  public static final CKA BIP32_VERSION_BYTES = new CKA(2147488001L);
  
  public static final CKA BIP32_CHILD_INDEX = new CKA(2147488002L);
  
  public static final CKA BIP32_CHILD_DEPTH = new CKA(2147488003L);
  
  public static final CKA BIP32_ID = new CKA(2147488004L);
  
  public static final CKA BIP32_FINGERPRINT = new CKA(2147488005L);
  
  public static final CKA BIP32_PARENT_FINGERPRINT = new CKA(2147488006L);
  
  public static final CKA USAGE_COUNT = new CKA(2147483905L);
  
  public static final CKA TIME_STAMP = new CKA(2147483906L);
  
  public static final CKA CHECK_VALUE_DEPRECATED = new CKA(2147483907L);
  
  public static final CKA MECHANISM_LIST = new CKA(2147483908L);
  
  public static final CKA SIGN_LOCAL_CERT = new CKA(2147483943L);
  
  public static final CKA EXPORT = new CKA(2147483944L);
  
  public static final CKA EXPORTABLE = new CKA(2147483945L);
  
  public static final CKA DELETABLE = new CKA(2147483946L);
  
  public static final CKA IMPORT = new CKA(2147483947L);
  
  public static final CKA KEY_SIZE = new CKA(2147483948L);
  
  public static final CKA ISSUER_STR = new CKA(2147483952L);
  
  public static final CKA SUBJECT_STR = new CKA(2147483953L);
  
  public static final CKA SERIAL_NUMBER_INT = new CKA(2147483954L);
  
  public static final CKA RECORD_COUNT = new CKA(2147483958L);
  
  public static final CKA RECORD_NUMBER = new CKA(2147483959L);
  
  public static final CKA PURGE = new CKA(2147483961L);
  
  public static final CKA EVENT_LOG_FULL = new CKA(2147483962L);
  
  public static final CKA SECURITY_MODE = new CKA(2147483968L);
  
  public static final CKA TRANSPORT_MODE = new CKA(2147483969L);
  
  public static final CKA BATCH = new CKA(2147483970L);
  
  public static final CKA HW_STATUS = new CKA(2147483971L);
  
  public static final CKA FREE_MEM = new CKA(2147483972L);
  
  public static final CKA TAMPER_CMD = new CKA(2147483973L);
  
  public static final CKA DATE_OF_MANUFACTURE = new CKA(2147483974L);
  
  public static final CKA HALT_CMD = new CKA(2147483975L);
  
  public static final CKA APPLICATION_COUNT = new CKA(2147483976L);
  
  public static final CKA FW_VERSION = new CKA(2147483977L);
  
  public static final CKA RESCAN_PERIPHERALS_CMD = new CKA(2147483978L);
  
  public static final CKA RTC_AAC_ENABLED = new CKA(2147483979L);
  
  public static final CKA RTC_AAC_GUARD_SECONDS = new CKA(2147483980L);
  
  public static final CKA RTC_AAC_GUARD_COUNT = new CKA(2147483981L);
  
  public static final CKA RTC_AAC_GUARD_DURATION = new CKA(2147483982L);
  
  public static final CKA HW_EXT_INFO_STR = new CKA(2147483983L);
  
  public static final CKA SLOT_ID = new CKA(2147483985L);
  
  public static final CKA MAX_SESSIONS = new CKA(2147483989L);
  
  public static final CKA MIN_PIN_LEN = new CKA(2147483990L);
  
  public static final CKA MAX_PIN_FAIL = new CKA(2147483992L);
  
  public static final CKA FLAGS = new CKA(2147483993L);
  
  public static final CKA VERIFY_OS = new CKA(2147484016L);
  
  public static final CKA VERSION = new CKA(2147484033L);
  
  public static final CKA MANUFACTURER = new CKA(2147484034L);
  
  public static final CKA BUILD_DATE = new CKA(2147484035L);
  
  public static final CKA FINGERPRINT = new CKA(2147484036L);
  
  public static final CKA ROM_SPACE = new CKA(2147484037L);
  
  public static final CKA RAM_SPACE = new CKA(2147484038L);
  
  public static final CKA FM_STATUS = new CKA(2147484039L);
  
  public static final CKA DELETE_FM = new CKA(2147484040L);
  
  public static final CKA FM_STARTUP_STATUS = new CKA(2147484041L);
  
  public static final CKA CERTIFICATE_START_TIME = new CKA(2147484048L);
  
  public static final CKA CERTIFICATE_END_TIME = new CKA(2147484049L);
  
  public static final CKA USAGE_LIMIT = new CKA(2147484160L);
  
  public static final CKA ADMIN_CERT = new CKA(2147484161L);
  
  public static final CKA PKI_ATTRIBUTE_BER_ENCODED = new CKA(2147484208L);
  
  public static final CKA TR31_INFO = new CKA(2147484320L);
  
  public static final CKA HIFACE_MASTER = new CKA(2147484240L);
  
  public static final CKA CKA_SEED = new CKA(2147484256L);
  
  public static final CKA CKA_COUNTER = new CKA(2147484257L);
  
  public static final CKA CKA_H_VALUE = new CKA(2147484258L);
  
  public static final CKA ENUM_ATTRIBUTE = new CKA(65535L);
  
  public static final CKA INVALID_VALUE = new CKA(-1L);
  
  public void setValue(long paramLong) {
    throw new UnsupportedOperationException("Not allowed to modify a CKA constant");
  }
  
  private CKA(long paramLong) {
    super(paramLong);
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/constants/CKA.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */