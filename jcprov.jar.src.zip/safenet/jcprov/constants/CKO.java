package safenet.jcprov.constants;

public class CKO extends CK_OBJECT_CLASS {
  public static final CKO DATA = new CKO(0L);
  
  public static final CKO CERTIFICATE = new CKO(1L);
  
  public static final CKO PUBLIC_KEY = new CKO(2L);
  
  public static final CKO PRIVATE_KEY = new CKO(3L);
  
  public static final CKO SECRET_KEY = new CKO(4L);
  
  public static final CKO HW_FEATURE = new CKO(5L);
  
  public static final CKO DOMAIN_PARAMETERS = new CKO(6L);
  
  public static final CKO CERTIFICATE_REQUEST = new CKO(2147484161L);
  
  public static final CKO CRL = new CKO(2147484162L);
  
  public static final CKO ADAPTER = new CKO(2147484170L);
  
  public static final CKO SLOT = new CKO(2147484171L);
  
  public static final CKO FM = new CKO(2147484172L);
  
  public static final CKO INVALID_VALUE = new CKO(-1L);
  
  public void setValue(long paramLong) {
    throw new UnsupportedOperationException("Not allowed to modify a CKO constant");
  }
  
  private CKO(long paramLong) {
    super(paramLong);
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/constants/CKO.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */