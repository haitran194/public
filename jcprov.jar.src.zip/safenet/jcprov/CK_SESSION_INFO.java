package safenet.jcprov;

import safenet.jcprov.constants.CK_STATE;

public class CK_SESSION_INFO {
  public long slotID;
  
  public CK_STATE state = new CK_STATE();
  
  public long flags;
  
  public long deviceError;
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/CK_SESSION_INFO.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */