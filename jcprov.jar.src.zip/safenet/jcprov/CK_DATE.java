package safenet.jcprov;

public class CK_DATE {
  public byte[] year = new byte[] { 48, 48, 48, 48 };
  
  public byte[] month = new byte[] { 48, 48 };
  
  public byte[] day = new byte[] { 48, 48 };
  
  public CK_DATE() {}
  
  public CK_DATE(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3) {}
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/CK_DATE.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */