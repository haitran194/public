package safenet.jcprov;

public class CK_INFO {
  public CK_VERSION cryptokiVersion = new CK_VERSION();
  
  public byte[] manufacturerID = new byte[32];
  
  public long flags;
  
  public byte[] libraryDescription = new byte[32];
  
  public CK_VERSION libraryVersion = new CK_VERSION();
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/CK_INFO.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */