package safenet.jcprov;

public class CK_BBOOL {
  public static final CK_BBOOL TRUE = new Constant(true);
  
  public static final CK_BBOOL FALSE = new Constant(false);
  
  private boolean m_value = false;
  
  public int hashCode() {
    return this.m_value ? 1 : 0;
  }
  
  public CK_BBOOL() {}
  
  public CK_BBOOL(boolean paramBoolean) {}
  
  public boolean booleanValue() {
    return this.m_value;
  }
  
  public void setValue(boolean paramBoolean) {
    this.m_value = paramBoolean;
  }
  
  public String toString() {
    return this.m_value ? "true" : "false";
  }
  
  public boolean equals(Object paramObject) {
    return (paramObject != null && paramObject instanceof CK_BBOOL && ((CK_BBOOL)paramObject).booleanValue() == this.m_value);
  }
  
  static class Constant extends CK_BBOOL {
    public void setValue(boolean param1Boolean) {
      throw new UnsupportedOperationException("Not allowed to modify a CK_BBOOL constant");
    }
    
    private Constant(boolean param1Boolean) {
      super(param1Boolean);
    }
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/CK_BBOOL.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */