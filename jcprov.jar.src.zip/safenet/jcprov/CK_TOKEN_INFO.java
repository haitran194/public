package safenet.jcprov;

public class CK_TOKEN_INFO {
  public byte[] label = new byte[32];
  
  public byte[] manufacturerID = new byte[32];
  
  public byte[] model = new byte[16];
  
  public byte[] serialNumber = new byte[16];
  
  public long flags;
  
  public long maxSessionCount;
  
  public long sessionCount;
  
  public long maxRwSessionCount;
  
  public long rwSessionCount;
  
  public long maxPinLen;
  
  public long minPinLen;
  
  public long totalPublicMemory;
  
  public long freePublicMemory;
  
  public long totalPrivateMemory;
  
  public long freePrivateMemory;
  
  public CK_VERSION hardwareVersion = new CK_VERSION();
  
  public CK_VERSION firmwareVersion = new CK_VERSION();
  
  public byte[] utcTime = new byte[16];
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/CK_TOKEN_INFO.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */