package safenet.jcprov;

import safenet.jcprov.constants.CK_ATTRIBUTE_TYPE;
import safenet.jcprov.constants.CK_KEY_TYPE;
import safenet.jcprov.constants.CK_MECHANISM_TYPE;
import safenet.jcprov.constants.CK_OBJECT_CLASS;
import safenet.jcprov.constants.CK_RV;
import safenet.jcprov.constants.CK_STATE;

public class CTUtil {
  public static native CK_RV CTU_GetErrorString(CK_RV paramCK_RV, byte[] paramArrayOfbyte, LongRef paramLongRef);
  
  public static native CK_RV CTU_GetErrorValue(byte[] paramArrayOfbyte);
  
  public static native CK_RV CTU_GetObjectClassString(CK_OBJECT_CLASS paramCK_OBJECT_CLASS, byte[] paramArrayOfbyte, LongRef paramLongRef);
  
  public static native CK_OBJECT_CLASS CTU_GetObjectClassValue(byte[] paramArrayOfbyte);
  
  public static native CK_RV CTU_GetKeyTypeString(CK_KEY_TYPE paramCK_KEY_TYPE, byte[] paramArrayOfbyte, LongRef paramLongRef);
  
  public static native CK_KEY_TYPE CTU_GetKeyTypeValue(byte[] paramArrayOfbyte);
  
  public static native CK_RV CTU_GetAttributeTypeString(CK_ATTRIBUTE_TYPE paramCK_ATTRIBUTE_TYPE, byte[] paramArrayOfbyte, LongRef paramLongRef);
  
  public static native CK_ATTRIBUTE_TYPE CTU_GetAttributeTypeValue(byte[] paramArrayOfbyte);
  
  public static native CK_RV CTU_GetMechanismTypeString(CK_MECHANISM_TYPE paramCK_MECHANISM_TYPE, byte[] paramArrayOfbyte, LongRef paramLongRef);
  
  public static native CK_RV CTU_DerEncodeNamedCurve(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, LongRef paramLongRef);
  
  public static native CK_MECHANISM_TYPE CTU_GetMechanismTypeValue(byte[] paramArrayOfbyte);
  
  public static native CK_RV CTU_GetSessionStateString(CK_STATE paramCK_STATE, byte[] paramArrayOfbyte, LongRef paramLongRef);
  
  public static native CK_STATE CTU_GetSessionStateValue(byte[] paramArrayOfbyte);
  
  public static native CK_RV CTU_FindObject(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_OBJECT_CLASS paramCK_OBJECT_CLASS, byte[] paramArrayOfbyte, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE);
  
  public static native CK_RV CTU_GetAttributeValue(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE, CK_ATTRIBUTE_TYPE paramCK_ATTRIBUTE_TYPE, Object paramObject, long paramLong, LongRef paramLongRef);
  
  public static native CK_RV CTU_SetAttributeValue(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE, CK_ATTRIBUTE_TYPE paramCK_ATTRIBUTE_TYPE, Object paramObject, long paramLong);
  
  static {
    System.loadLibrary("jcprov");
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/CTUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */