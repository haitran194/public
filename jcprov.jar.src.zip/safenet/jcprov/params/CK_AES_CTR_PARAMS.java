package safenet.jcprov.params;

public class CK_AES_CTR_PARAMS {
  public byte[] cb = new byte[] { 
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0, 0 };
  
  public long ulCounterBits = 32L;
  
  public CK_AES_CTR_PARAMS() {}
  
  public CK_AES_CTR_PARAMS(byte[] paramArrayOfbyte, long paramLong) {}
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_AES_CTR_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */