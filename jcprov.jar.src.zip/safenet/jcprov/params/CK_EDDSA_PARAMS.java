package safenet.jcprov.params;

public class CK_EDDSA_PARAMS {
  public boolean phFlag = false;
  
  public byte[] pContextData = null;
  
  public CK_EDDSA_PARAMS() {}
  
  public CK_EDDSA_PARAMS(boolean paramBoolean) {}
  
  public CK_EDDSA_PARAMS(boolean paramBoolean, byte[] paramArrayOfbyte) {}
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_EDDSA_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */