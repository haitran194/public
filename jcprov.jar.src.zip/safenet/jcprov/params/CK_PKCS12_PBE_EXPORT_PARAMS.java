package safenet.jcprov.params;

import safenet.jcprov.CK_OBJECT_HANDLE;
import safenet.jcprov.constants.CKM;
import safenet.jcprov.constants.CK_MECHANISM_TYPE;

public class CK_PKCS12_PBE_EXPORT_PARAMS {
  public CK_OBJECT_HANDLE keyCert;
  
  public byte[] passwordAuthSafe;
  
  public long passwordAuthSafeLen;
  
  public byte[] passwordHMAC;
  
  public long passwordHMACLen;
  
  public CK_MECHANISM_TYPE safeBagKgMech;
  
  public CK_MECHANISM_TYPE safeContentKgMech;
  
  public CK_MECHANISM_TYPE hmacKgMech;
  
  public CK_PKCS12_PBE_EXPORT_PARAMS() {}
  
  public CK_PKCS12_PBE_EXPORT_PARAMS(CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE, byte[] paramArrayOfbyte1, long paramLong1, byte[] paramArrayOfbyte2, long paramLong2, CK_MECHANISM_TYPE paramCK_MECHANISM_TYPE1, CK_MECHANISM_TYPE paramCK_MECHANISM_TYPE2, CK_MECHANISM_TYPE paramCK_MECHANISM_TYPE3) {
    this.keyCert = paramCK_OBJECT_HANDLE;
    this.passwordAuthSafe = paramArrayOfbyte1;
    this.passwordAuthSafeLen = paramLong1;
    this.passwordHMAC = paramArrayOfbyte2;
    this.passwordHMACLen = paramLong2;
    this.safeBagKgMech = paramCK_MECHANISM_TYPE1;
    this.safeContentKgMech = paramCK_MECHANISM_TYPE2;
    this.hmacKgMech = paramCK_MECHANISM_TYPE3;
  }
  
  public CK_PKCS12_PBE_EXPORT_PARAMS(CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, CK_MECHANISM_TYPE paramCK_MECHANISM_TYPE1, CK_MECHANISM_TYPE paramCK_MECHANISM_TYPE2, CK_MECHANISM_TYPE paramCK_MECHANISM_TYPE3) {
    this.keyCert = paramCK_OBJECT_HANDLE;
    this.passwordAuthSafe = paramArrayOfbyte1;
    this.passwordAuthSafeLen = paramArrayOfbyte1.length;
    this.passwordHMAC = paramArrayOfbyte2;
    this.passwordHMACLen = paramArrayOfbyte2.length;
    this.safeBagKgMech = paramCK_MECHANISM_TYPE1;
    this.safeContentKgMech = paramCK_MECHANISM_TYPE2;
    this.hmacKgMech = paramCK_MECHANISM_TYPE3;
  }
  
  public CK_PKCS12_PBE_EXPORT_PARAMS(CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    this.keyCert = paramCK_OBJECT_HANDLE;
    this.passwordAuthSafe = paramArrayOfbyte1;
    this.passwordAuthSafeLen = paramArrayOfbyte1.length;
    this.passwordHMAC = paramArrayOfbyte2;
    this.passwordHMACLen = paramArrayOfbyte2.length;
    this.safeBagKgMech = (CK_MECHANISM_TYPE)CKM.PBE_SHA1_DES3_EDE_CBC;
    this.safeContentKgMech = (CK_MECHANISM_TYPE)CKM.PBE_SHA1_RC2_40_CBC;
    this.hmacKgMech = (CK_MECHANISM_TYPE)CKM.PBA_SHA1_WITH_SHA1_HMAC;
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_PKCS12_PBE_EXPORT_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */