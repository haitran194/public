package safenet.jcprov.params;

public class CK_KEY_DERIVATION_STRING_DATA {
  public byte[] pData;
  
  public long len;
  
  public CK_KEY_DERIVATION_STRING_DATA() {}
  
  public CK_KEY_DERIVATION_STRING_DATA(byte[] paramArrayOfbyte, long paramLong) {
    this.pData = paramArrayOfbyte;
    this.len = paramLong;
  }
  
  public CK_KEY_DERIVATION_STRING_DATA(byte[] paramArrayOfbyte) {
    this.pData = paramArrayOfbyte;
    this.len = paramArrayOfbyte.length;
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_KEY_DERIVATION_STRING_DATA.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */