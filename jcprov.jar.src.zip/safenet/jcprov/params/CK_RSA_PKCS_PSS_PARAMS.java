package safenet.jcprov.params;

import safenet.jcprov.constants.CK_MECHANISM_TYPE;

public class CK_RSA_PKCS_PSS_PARAMS {
  public CK_MECHANISM_TYPE hashAlg;
  
  public long mgf;
  
  public long sLen;
  
  public CK_RSA_PKCS_PSS_PARAMS() {}
  
  public CK_RSA_PKCS_PSS_PARAMS(CK_MECHANISM_TYPE paramCK_MECHANISM_TYPE, long paramLong1, long paramLong2) {
    this.hashAlg = paramCK_MECHANISM_TYPE;
    this.mgf = paramLong1;
    this.sLen = paramLong2;
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_RSA_PKCS_PSS_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */