package safenet.jcprov.params;

import safenet.jcprov.CK_VERSION;

public class CK_SSL3_MASTER_KEY_DERIVE_PARAMS {
  public CK_SSL3_RANDOM_DATA RandomInfo = new CK_SSL3_RANDOM_DATA();
  
  public CK_VERSION pVersion = new CK_VERSION();
  
  public CK_SSL3_MASTER_KEY_DERIVE_PARAMS() {}
  
  public CK_SSL3_MASTER_KEY_DERIVE_PARAMS(CK_SSL3_RANDOM_DATA paramCK_SSL3_RANDOM_DATA, CK_VERSION paramCK_VERSION) {}
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_SSL3_MASTER_KEY_DERIVE_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */