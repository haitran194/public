package safenet.jcprov.params;

import safenet.jcprov.CK_ATTRIBUTE;
import safenet.jcprov.CK_OBJECT_HANDLE;
import safenet.jcprov.LongRef;

public class CK_PKCS12_PBE_IMPORT_PARAMS {
  public byte[] passwordAuthSafe;
  
  public long passwordAuthSafeLen;
  
  public byte[] passwordHMAC;
  
  public long passwordHMACLen;
  
  public CK_ATTRIBUTE[] certAttr;
  
  public long certAttrCount;
  
  public CK_OBJECT_HANDLE[] hCert;
  
  public LongRef hCertCount;
  
  public CK_PKCS12_PBE_IMPORT_PARAMS() {}
  
  public CK_PKCS12_PBE_IMPORT_PARAMS(byte[] paramArrayOfbyte1, long paramLong1, byte[] paramArrayOfbyte2, long paramLong2, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE, long paramLong3, CK_OBJECT_HANDLE[] paramArrayOfCK_OBJECT_HANDLE, LongRef paramLongRef) {
    this.passwordAuthSafe = paramArrayOfbyte1;
    this.passwordAuthSafeLen = paramLong1;
    this.passwordHMAC = paramArrayOfbyte2;
    this.passwordHMACLen = paramLong2;
    this.certAttr = paramArrayOfCK_ATTRIBUTE;
    this.certAttrCount = paramLong3;
    if (paramArrayOfCK_OBJECT_HANDLE != null) {
      this.hCert = paramArrayOfCK_OBJECT_HANDLE;
    } else {
      this.hCert = null;
    } 
    this.hCertCount = paramLongRef;
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_PKCS12_PBE_IMPORT_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */