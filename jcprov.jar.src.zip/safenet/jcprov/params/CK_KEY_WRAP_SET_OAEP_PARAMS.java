package safenet.jcprov.params;

public class CK_KEY_WRAP_SET_OAEP_PARAMS {
  public byte bBC;
  
  public byte[] pX;
  
  public long XLen;
  
  public CK_KEY_WRAP_SET_OAEP_PARAMS() {}
  
  public CK_KEY_WRAP_SET_OAEP_PARAMS(byte paramByte, byte[] paramArrayOfbyte, long paramLong) {
    this.bBC = paramByte;
    this.pX = paramArrayOfbyte;
    this.XLen = paramLong;
  }
  
  public CK_KEY_WRAP_SET_OAEP_PARAMS(byte paramByte, byte[] paramArrayOfbyte) {
    this.bBC = paramByte;
    this.pX = paramArrayOfbyte;
    this.XLen = paramArrayOfbyte.length;
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_KEY_WRAP_SET_OAEP_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */