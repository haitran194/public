package safenet.jcprov.params;

public class CK_KDE_TOKEN_WRAP_PARAMS {
  public static final int CK_KDE_MACTAG_LEN = 64;
  
  public byte[] bPeerMacTag;
  
  public CK_KDE_TOKEN_WRAP_PARAMS() {}
  
  public CK_KDE_TOKEN_WRAP_PARAMS(byte[] paramArrayOfbyte) {
    this.bPeerMacTag = (byte[])paramArrayOfbyte.clone();
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_KDE_TOKEN_WRAP_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */