package safenet.jcprov.params;

public class CK_SECRET_SHARE_PARAMS {
  public long n = 2L;
  
  public long m = 2L;
  
  public CK_SECRET_SHARE_PARAMS() {}
  
  public CK_SECRET_SHARE_PARAMS(long paramLong1, long paramLong2) {}
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_SECRET_SHARE_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */