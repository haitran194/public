package safenet.jcprov.params;

public class CK_DES3_CBC_PARAMS {
  public byte[] iv = new byte[8];
  
  public byte[] data = new byte[24];
  
  public CK_DES3_CBC_PARAMS() {}
  
  public CK_DES3_CBC_PARAMS(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {}
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_DES3_CBC_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */