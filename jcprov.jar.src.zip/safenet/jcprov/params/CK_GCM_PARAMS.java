package safenet.jcprov.params;

public class CK_GCM_PARAMS {
  public byte[] pIv = null;
  
  public long ulIvLen = 0L;
  
  public byte[] pAAD = null;
  
  public long ulAADLen = 0L;
  
  public long ulTagBits = 128L;
  
  public CK_GCM_PARAMS() {}
  
  public CK_GCM_PARAMS(long paramLong) {}
  
  public CK_GCM_PARAMS(byte[] paramArrayOfbyte1, int paramInt, byte[] paramArrayOfbyte2, long paramLong1, long paramLong2) {}
  
  public CK_GCM_PARAMS(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, long paramLong) {}
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_GCM_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */