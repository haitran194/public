package safenet.jcprov.params;

public class CK_ECDH1_DERIVE_PARAMS {
  public long kdf;
  
  public long ulSharedDataLen;
  
  public byte[] pSharedData;
  
  public long ulPublicDataLen;
  
  public byte[] pPublicData;
  
  public CK_ECDH1_DERIVE_PARAMS() {}
  
  public CK_ECDH1_DERIVE_PARAMS(long paramLong1, long paramLong2, byte[] paramArrayOfbyte1, long paramLong3, byte[] paramArrayOfbyte2) {
    this.kdf = paramLong1;
    this.ulSharedDataLen = paramLong2;
    this.pSharedData = paramArrayOfbyte1;
    this.ulPublicDataLen = paramLong3;
    this.pPublicData = paramArrayOfbyte2;
  }
  
  public CK_ECDH1_DERIVE_PARAMS(long paramLong1, long paramLong2, byte[] paramArrayOfbyte) {
    this.kdf = paramLong1;
    this.ulSharedDataLen = 0L;
    this.ulPublicDataLen = paramLong2;
    this.pPublicData = paramArrayOfbyte;
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_ECDH1_DERIVE_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */