package safenet.jcprov.params;

public class CK_DES_CBC_ENCRYPT_DATA_PARAMS {
  public byte[] iv;
  
  public byte[] pData;
  
  public long length;
  
  public CK_DES_CBC_ENCRYPT_DATA_PARAMS() {}
  
  public CK_DES_CBC_ENCRYPT_DATA_PARAMS(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, long paramLong) {
    this.iv = paramArrayOfbyte1;
    this.pData = paramArrayOfbyte2;
    this.length = paramLong;
  }
  
  public CK_DES_CBC_ENCRYPT_DATA_PARAMS(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    this.iv = paramArrayOfbyte1;
    this.pData = paramArrayOfbyte2;
    this.length = paramArrayOfbyte2.length;
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_DES_CBC_ENCRYPT_DATA_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */