package safenet.jcprov.params;

public class CK_GEN_PIK_PARAM {
  public boolean bSelfSign = false;
  
  public CK_GEN_PIK_PARAM() {}
  
  public CK_GEN_PIK_PARAM(boolean paramBoolean) {}
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_GEN_PIK_PARAM.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */