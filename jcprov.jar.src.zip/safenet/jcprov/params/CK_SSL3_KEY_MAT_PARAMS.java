package safenet.jcprov.params;

import safenet.jcprov.CK_BBOOL;

public class CK_SSL3_KEY_MAT_PARAMS {
  public long macSizeInBits;
  
  public long keySizeInBits;
  
  public long IVSizeInBits;
  
  public CK_BBOOL bIsExport;
  
  public CK_SSL3_RANDOM_DATA RandomInfo;
  
  public CK_SSL3_KEY_MAT_OUT pReturnedKeyMaterial;
  
  public CK_SSL3_KEY_MAT_PARAMS() {}
  
  public CK_SSL3_KEY_MAT_PARAMS(long paramLong1, long paramLong2, long paramLong3, CK_BBOOL paramCK_BBOOL, CK_SSL3_RANDOM_DATA paramCK_SSL3_RANDOM_DATA, CK_SSL3_KEY_MAT_OUT paramCK_SSL3_KEY_MAT_OUT) {
    this.macSizeInBits = paramLong1;
    this.keySizeInBits = paramLong2;
    this.IVSizeInBits = paramLong3;
    this.bIsExport = paramCK_BBOOL;
    this.RandomInfo = paramCK_SSL3_RANDOM_DATA;
    this.pReturnedKeyMaterial = paramCK_SSL3_KEY_MAT_OUT;
  }
  
  public CK_SSL3_KEY_MAT_PARAMS(long paramLong1, long paramLong2, long paramLong3, CK_BBOOL paramCK_BBOOL, CK_SSL3_RANDOM_DATA paramCK_SSL3_RANDOM_DATA) {
    this.macSizeInBits = paramLong1;
    this.keySizeInBits = paramLong2;
    this.IVSizeInBits = paramLong3;
    this.bIsExport = paramCK_BBOOL;
    this.RandomInfo = paramCK_SSL3_RANDOM_DATA;
    if (paramLong3 > 0L) {
      this.pReturnedKeyMaterial = new CK_SSL3_KEY_MAT_OUT(new byte[(int)(paramLong3 / 8L)], new byte[(int)(paramLong3 / 8L)]);
    } else {
      this.pReturnedKeyMaterial = new CK_SSL3_KEY_MAT_OUT();
    } 
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_SSL3_KEY_MAT_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */