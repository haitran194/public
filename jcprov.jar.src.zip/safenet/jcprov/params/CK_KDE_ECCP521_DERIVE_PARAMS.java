package safenet.jcprov.params;

public class CK_KDE_ECCP521_DERIVE_PARAMS {
  public byte[] pPeerKTC;
  
  public byte[] bMacTagOut;
  
  public CK_KDE_ECCP521_DERIVE_PARAMS(byte[] paramArrayOfbyte) {
    this.pPeerKTC = paramArrayOfbyte;
    this.bMacTagOut = new byte[64];
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_KDE_ECCP521_DERIVE_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */