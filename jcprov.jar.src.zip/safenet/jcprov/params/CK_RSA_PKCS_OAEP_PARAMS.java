package safenet.jcprov.params;

import safenet.jcprov.constants.CK_MECHANISM_TYPE;
import safenet.jcprov.constants.CK_RSA_PKCS_OAEP_SOURCE_TYPE;

public class CK_RSA_PKCS_OAEP_PARAMS {
  public CK_MECHANISM_TYPE hashAlg;
  
  public long mgf;
  
  public CK_RSA_PKCS_OAEP_SOURCE_TYPE source;
  
  public byte[] pSourceData;
  
  public long sourceDataLen;
  
  public CK_RSA_PKCS_OAEP_PARAMS() {}
  
  public CK_RSA_PKCS_OAEP_PARAMS(CK_MECHANISM_TYPE paramCK_MECHANISM_TYPE, long paramLong1, CK_RSA_PKCS_OAEP_SOURCE_TYPE paramCK_RSA_PKCS_OAEP_SOURCE_TYPE, byte[] paramArrayOfbyte, long paramLong2) {
    this.hashAlg = paramCK_MECHANISM_TYPE;
    this.mgf = paramLong1;
    this.source = paramCK_RSA_PKCS_OAEP_SOURCE_TYPE;
    this.pSourceData = paramArrayOfbyte;
    this.sourceDataLen = paramLong2;
  }
  
  public CK_RSA_PKCS_OAEP_PARAMS(CK_MECHANISM_TYPE paramCK_MECHANISM_TYPE, long paramLong, CK_RSA_PKCS_OAEP_SOURCE_TYPE paramCK_RSA_PKCS_OAEP_SOURCE_TYPE, byte[] paramArrayOfbyte) {
    this.hashAlg = paramCK_MECHANISM_TYPE;
    this.mgf = paramLong;
    this.source = paramCK_RSA_PKCS_OAEP_SOURCE_TYPE;
    this.pSourceData = paramArrayOfbyte;
    this.sourceDataLen = paramArrayOfbyte.length;
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_RSA_PKCS_OAEP_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */