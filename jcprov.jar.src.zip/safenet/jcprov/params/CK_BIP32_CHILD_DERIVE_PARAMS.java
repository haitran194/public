package safenet.jcprov.params;

import safenet.jcprov.CK_ATTRIBUTE;
import safenet.jcprov.CK_OBJECT_HANDLE;

public class CK_BIP32_CHILD_DERIVE_PARAMS {
  public CK_ATTRIBUTE[] publicKeyTemplate;
  
  public long publicKeyAttributeCount;
  
  public CK_ATTRIBUTE[] privateKeyTemplate;
  
  public long privateKeyAttributeCount;
  
  public long[] path;
  
  public long pathLen;
  
  public CK_OBJECT_HANDLE hPublicKey = new CK_OBJECT_HANDLE();
  
  public CK_OBJECT_HANDLE hPrivateKey = new CK_OBJECT_HANDLE();
  
  public long pathErrorIndex;
  
  public CK_BIP32_CHILD_DERIVE_PARAMS() {}
  
  public CK_BIP32_CHILD_DERIVE_PARAMS(CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE1, long paramLong1, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE2, long paramLong2, long[] paramArrayOflong, long paramLong3) {
    this.publicKeyTemplate = paramArrayOfCK_ATTRIBUTE1;
    this.publicKeyAttributeCount = paramLong1;
    this.privateKeyTemplate = paramArrayOfCK_ATTRIBUTE2;
    this.privateKeyAttributeCount = paramLong2;
    this.path = paramArrayOflong;
    this.pathLen = paramLong3;
  }
  
  public CK_BIP32_CHILD_DERIVE_PARAMS(CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE1, CK_ATTRIBUTE[] paramArrayOfCK_ATTRIBUTE2, long[] paramArrayOflong) {
    this.publicKeyTemplate = paramArrayOfCK_ATTRIBUTE1;
    this.publicKeyAttributeCount = paramArrayOfCK_ATTRIBUTE1.length;
    this.privateKeyTemplate = paramArrayOfCK_ATTRIBUTE2;
    this.privateKeyAttributeCount = paramArrayOfCK_ATTRIBUTE1.length;
    this.path = paramArrayOflong;
    this.pathLen = paramArrayOflong.length;
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_BIP32_CHILD_DERIVE_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */