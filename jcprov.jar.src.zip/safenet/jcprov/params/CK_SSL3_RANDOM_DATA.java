package safenet.jcprov.params;

public class CK_SSL3_RANDOM_DATA {
  public byte[] pClientRandom;
  
  public long clientRandomLen;
  
  public byte[] pServerRandom;
  
  public long serverRandomLen;
  
  public CK_SSL3_RANDOM_DATA() {}
  
  public CK_SSL3_RANDOM_DATA(byte[] paramArrayOfbyte1, long paramLong1, byte[] paramArrayOfbyte2, long paramLong2) {
    this.pClientRandom = paramArrayOfbyte1;
    this.clientRandomLen = paramLong1;
    this.pServerRandom = paramArrayOfbyte2;
    this.serverRandomLen = paramLong2;
  }
  
  public CK_SSL3_RANDOM_DATA(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    this.pClientRandom = paramArrayOfbyte1;
    this.clientRandomLen = paramArrayOfbyte1.length;
    this.pServerRandom = paramArrayOfbyte2;
    this.serverRandomLen = paramArrayOfbyte2.length;
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_SSL3_RANDOM_DATA.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */