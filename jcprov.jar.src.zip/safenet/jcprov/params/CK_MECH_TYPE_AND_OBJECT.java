package safenet.jcprov.params;

import safenet.jcprov.CK_OBJECT_HANDLE;
import safenet.jcprov.constants.CK_MECHANISM_TYPE;

public class CK_MECH_TYPE_AND_OBJECT {
  public CK_MECHANISM_TYPE mechanism;
  
  public CK_OBJECT_HANDLE hObj;
  
  public CK_MECH_TYPE_AND_OBJECT() {}
  
  public CK_MECH_TYPE_AND_OBJECT(CK_MECHANISM_TYPE paramCK_MECHANISM_TYPE, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE) {
    this.mechanism = paramCK_MECHANISM_TYPE;
    this.hObj = paramCK_OBJECT_HANDLE;
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_MECH_TYPE_AND_OBJECT.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */