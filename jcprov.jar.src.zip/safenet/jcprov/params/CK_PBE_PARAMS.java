package safenet.jcprov.params;

public class CK_PBE_PARAMS {
  public byte[] pInitVector;
  
  public byte[] pPassword;
  
  public long passwordLen;
  
  public byte[] pSalt;
  
  public long saltLen;
  
  public long iteration;
  
  public CK_PBE_PARAMS() {}
  
  public CK_PBE_PARAMS(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, long paramLong1, byte[] paramArrayOfbyte3, long paramLong2, long paramLong3) {
    this.pInitVector = paramArrayOfbyte1;
    this.pPassword = paramArrayOfbyte2;
    this.passwordLen = paramLong1;
    this.pSalt = paramArrayOfbyte3;
    this.saltLen = paramLong2;
    this.iteration = paramLong3;
  }
  
  public CK_PBE_PARAMS(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, long paramLong) {
    this.pInitVector = paramArrayOfbyte1;
    this.pPassword = paramArrayOfbyte2;
    this.passwordLen = paramArrayOfbyte2.length;
    this.pSalt = paramArrayOfbyte3;
    this.saltLen = paramArrayOfbyte3.length;
    this.iteration = paramLong;
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_PBE_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */