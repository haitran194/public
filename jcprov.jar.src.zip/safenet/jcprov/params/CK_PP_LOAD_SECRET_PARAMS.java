package safenet.jcprov.params;

import safenet.jcprov.CK_BBOOL;

public class CK_PP_LOAD_SECRET_PARAMS {
  public CK_BBOOL bMaskInput;
  
  public int cConvert;
  
  public int cTimeout;
  
  public byte[] prompt;
  
  public static final int CK_PP_CT_NONE = 0;
  
  public static final int CK_PP_CT_OCTAL = 8;
  
  public static final int CK_PP_CT_DECIMAL = 10;
  
  public static final int CK_PP_CT_HEX = 16;
  
  public CK_PP_LOAD_SECRET_PARAMS(CK_BBOOL paramCK_BBOOL, int paramInt1, int paramInt2, byte[] paramArrayOfbyte) {
    this.bMaskInput = paramCK_BBOOL;
    this.cConvert = paramInt1;
    this.cTimeout = paramInt2;
    this.prompt = paramArrayOfbyte;
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_PP_LOAD_SECRET_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */