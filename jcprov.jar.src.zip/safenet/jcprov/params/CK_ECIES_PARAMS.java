package safenet.jcprov.params;

public class CK_ECIES_PARAMS {
  public long dhPrimitive;
  
  public long kdf;
  
  public long ulSharedDataLen1;
  
  public byte[] pSharedData1;
  
  public long encScheme;
  
  public long ulEncKeyLenInBits;
  
  public long macScheme;
  
  public long ulMacKeyLenInBits;
  
  public long ulMacLenInBits;
  
  public long ulSharedDataLen2;
  
  public byte[] pSharedData2;
  
  public CK_ECIES_PARAMS() {}
  
  public CK_ECIES_PARAMS(long paramLong1, long paramLong2, long paramLong3, byte[] paramArrayOfbyte1, long paramLong4, long paramLong5, long paramLong6, long paramLong7, long paramLong8, long paramLong9, byte[] paramArrayOfbyte2) {
    this.dhPrimitive = paramLong1;
    this.kdf = paramLong2;
    this.ulSharedDataLen1 = paramLong3;
    this.pSharedData1 = paramArrayOfbyte1;
    this.encScheme = paramLong4;
    this.ulEncKeyLenInBits = paramLong5;
    this.macScheme = paramLong6;
    this.ulMacKeyLenInBits = paramLong7;
    this.ulMacLenInBits = paramLong8;
    this.ulSharedDataLen2 = paramLong9;
    this.pSharedData2 = paramArrayOfbyte2;
  }
  
  public CK_ECIES_PARAMS(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7) {
    this.dhPrimitive = paramLong1;
    this.kdf = paramLong2;
    this.encScheme = paramLong3;
    this.ulEncKeyLenInBits = paramLong4;
    this.macScheme = paramLong5;
    this.ulMacKeyLenInBits = paramLong6;
    this.ulMacLenInBits = paramLong7;
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_ECIES_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */