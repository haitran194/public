package safenet.jcprov.params;

public class CK_RC2_CBC_PARAMS {
  public long effectiveBits;
  
  public byte[] iv;
  
  public CK_RC2_CBC_PARAMS() {
    this.iv = new byte[8];
  }
  
  public CK_RC2_CBC_PARAMS(long paramLong, byte[] paramArrayOfbyte) {
    this.effectiveBits = paramLong;
    this.iv = paramArrayOfbyte;
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_RC2_CBC_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */