package safenet.jcprov.params;

public class CK_AES_GCM_PARAMS extends CK_GCM_PARAMS {
  public CK_AES_GCM_PARAMS() {}
  
  public CK_AES_GCM_PARAMS(long paramLong) {
    super(paramLong);
  }
  
  public CK_AES_GCM_PARAMS(byte[] paramArrayOfbyte1, int paramInt, byte[] paramArrayOfbyte2, long paramLong1, long paramLong2) {
    super(paramArrayOfbyte1, paramInt, paramArrayOfbyte2, paramLong1, paramLong2);
  }
  
  public CK_AES_GCM_PARAMS(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, long paramLong) {
    super(paramArrayOfbyte1, paramArrayOfbyte2, paramLong);
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_AES_GCM_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */