package safenet.jcprov.params;

import safenet.jcprov.CK_BBOOL;

public class CK_TIMESTAMP_PARAMS {
  public CK_BBOOL useMilliseconds;
  
  public long timestampFormat;
  
  public CK_TIMESTAMP_PARAMS() {}
  
  public CK_TIMESTAMP_PARAMS(CK_BBOOL paramCK_BBOOL, long paramLong) {
    this.useMilliseconds = paramCK_BBOOL;
    this.timestampFormat = paramLong;
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_TIMESTAMP_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */