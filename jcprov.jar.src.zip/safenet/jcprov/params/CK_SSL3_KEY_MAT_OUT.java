package safenet.jcprov.params;

import safenet.jcprov.CK_OBJECT_HANDLE;

public class CK_SSL3_KEY_MAT_OUT {
  public CK_OBJECT_HANDLE hClientMacSecret;
  
  public CK_OBJECT_HANDLE hServerMacSecret;
  
  public CK_OBJECT_HANDLE hClientKey;
  
  public CK_OBJECT_HANDLE hServerKey;
  
  public byte[] pIVClient;
  
  public byte[] pIVServer;
  
  public CK_SSL3_KEY_MAT_OUT() {}
  
  public CK_SSL3_KEY_MAT_OUT(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    this.pIVClient = paramArrayOfbyte1;
    this.pIVServer = paramArrayOfbyte2;
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_SSL3_KEY_MAT_OUT.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */