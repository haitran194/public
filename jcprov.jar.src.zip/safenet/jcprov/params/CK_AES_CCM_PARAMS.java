package safenet.jcprov.params;

public class CK_AES_CCM_PARAMS {
  public long ulDataLen;
  
  public byte[] pNonce;
  
  public long ulNonceLen;
  
  public byte[] pAAD;
  
  public long ulAADLen;
  
  public long ulMACLen;
  
  public CK_AES_CCM_PARAMS() {
    this.ulDataLen = 0L;
    this.pNonce = null;
    this.ulNonceLen = 0L;
    this.pAAD = null;
    this.ulAADLen = 0L;
    this.ulMACLen = 8L;
  }
  
  public CK_AES_CCM_PARAMS(long paramLong) {
    this.ulDataLen = 0L;
    this.pNonce = null;
    this.ulNonceLen = 0L;
    this.pAAD = null;
    this.ulAADLen = 0L;
    this.ulMACLen = paramLong;
  }
  
  public CK_AES_CCM_PARAMS(int paramInt1, byte[] paramArrayOfbyte1, int paramInt2, byte[] paramArrayOfbyte2, long paramLong1, long paramLong2) {
    this.ulDataLen = paramInt1;
    this.pNonce = paramArrayOfbyte1;
    this.ulNonceLen = paramInt2;
    this.pAAD = paramArrayOfbyte2;
    this.ulAADLen = paramLong1;
    this.ulMACLen = paramLong2;
  }
  
  public CK_AES_CCM_PARAMS(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, long paramLong) {
    this.pNonce = paramArrayOfbyte1;
    this.ulNonceLen = paramArrayOfbyte1.length;
    this.pAAD = paramArrayOfbyte2;
    this.ulAADLen = paramArrayOfbyte2.length;
    this.ulMACLen = paramLong;
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/params/CK_AES_CCM_PARAMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */