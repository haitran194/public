package safenet.jcprov;

public class CK_C_INITIALIZE_ARGS {
  public CK_CREATEMUTEX createMutex;
  
  public CK_DESTROYMUTEX destroyMutex;
  
  public CK_LOCKMUTEX lockMutex;
  
  public CK_UNLOCKMUTEX unlockMutex;
  
  public long flags;
  
  public Object reserved;
  
  public CK_C_INITIALIZE_ARGS() {}
  
  public CK_C_INITIALIZE_ARGS(long paramLong) {
    this.flags = paramLong;
  }
  
  public CK_C_INITIALIZE_ARGS(CK_CREATEMUTEX paramCK_CREATEMUTEX, CK_DESTROYMUTEX paramCK_DESTROYMUTEX, CK_LOCKMUTEX paramCK_LOCKMUTEX, CK_UNLOCKMUTEX paramCK_UNLOCKMUTEX) {
    this.createMutex = paramCK_CREATEMUTEX;
    this.destroyMutex = paramCK_DESTROYMUTEX;
    this.lockMutex = paramCK_LOCKMUTEX;
    this.unlockMutex = paramCK_UNLOCKMUTEX;
    this.flags = 0L;
  }
  
  public CK_C_INITIALIZE_ARGS(CK_CREATEMUTEX paramCK_CREATEMUTEX, CK_DESTROYMUTEX paramCK_DESTROYMUTEX, CK_LOCKMUTEX paramCK_LOCKMUTEX, CK_UNLOCKMUTEX paramCK_UNLOCKMUTEX, long paramLong) {
    this.createMutex = paramCK_CREATEMUTEX;
    this.destroyMutex = paramCK_DESTROYMUTEX;
    this.lockMutex = paramCK_LOCKMUTEX;
    this.unlockMutex = paramCK_UNLOCKMUTEX;
    this.flags = paramLong;
  }
  
  public static interface CK_UNLOCKMUTEX {
    long UnlockMutex(Object param1Object);
  }
  
  public static interface CK_LOCKMUTEX {
    long LockMutex(Object param1Object);
  }
  
  public static interface CK_DESTROYMUTEX {
    long DestroyMutex(Object param1Object);
  }
  
  public static interface CK_CREATEMUTEX {
    Object CreateMutex();
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/CK_C_INITIALIZE_ARGS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */