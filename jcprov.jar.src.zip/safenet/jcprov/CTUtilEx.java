package safenet.jcprov;

import safenet.jcprov.constants.CKR;
import safenet.jcprov.constants.CK_ATTRIBUTE_TYPE;
import safenet.jcprov.constants.CK_KEY_TYPE;
import safenet.jcprov.constants.CK_MECHANISM_TYPE;
import safenet.jcprov.constants.CK_OBJECT_CLASS;
import safenet.jcprov.constants.CK_RV;
import safenet.jcprov.constants.CK_STATE;

public class CTUtilEx {
  public static CK_RV CTU_GetErrorString(CK_RV paramCK_RV, byte[] paramArrayOfbyte, LongRef paramLongRef) {
    CK_RV cK_RV = CTUtil.CTU_GetErrorString(paramCK_RV, paramArrayOfbyte, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("CTU_GetErrorString", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV CTU_GetErrorValue(byte[] paramArrayOfbyte) {
    return CTUtil.CTU_GetErrorValue(paramArrayOfbyte);
  }
  
  public static CK_RV CTU_GetObjectClassString(CK_OBJECT_CLASS paramCK_OBJECT_CLASS, byte[] paramArrayOfbyte, LongRef paramLongRef) {
    CK_RV cK_RV = CTUtil.CTU_GetObjectClassString(paramCK_OBJECT_CLASS, paramArrayOfbyte, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("CTU_GetObjectClassString", cK_RV); 
    return cK_RV;
  }
  
  public static CK_OBJECT_CLASS CTU_GetObjectClassValue(byte[] paramArrayOfbyte) {
    return CTUtil.CTU_GetObjectClassValue(paramArrayOfbyte);
  }
  
  public static CK_RV CTU_GetKeyTypeString(CK_KEY_TYPE paramCK_KEY_TYPE, byte[] paramArrayOfbyte, LongRef paramLongRef) {
    CK_RV cK_RV = CTUtil.CTU_GetKeyTypeString(paramCK_KEY_TYPE, paramArrayOfbyte, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("CTU_GetKeyTypeString", cK_RV); 
    return cK_RV;
  }
  
  public static CK_KEY_TYPE CTU_GetKeyTypeValue(byte[] paramArrayOfbyte) {
    return CTUtil.CTU_GetKeyTypeValue(paramArrayOfbyte);
  }
  
  public static CK_RV CTU_GetAttributeTypeString(CK_ATTRIBUTE_TYPE paramCK_ATTRIBUTE_TYPE, byte[] paramArrayOfbyte, LongRef paramLongRef) {
    CK_RV cK_RV = CTUtil.CTU_GetAttributeTypeString(paramCK_ATTRIBUTE_TYPE, paramArrayOfbyte, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("CTU_GetAttributeTypeString", cK_RV); 
    return cK_RV;
  }
  
  public static CK_ATTRIBUTE_TYPE CTU_GetAttributeTypeValue(byte[] paramArrayOfbyte) {
    return CTUtil.CTU_GetAttributeTypeValue(paramArrayOfbyte);
  }
  
  public static CK_RV CTU_GetMechanismTypeString(CK_MECHANISM_TYPE paramCK_MECHANISM_TYPE, byte[] paramArrayOfbyte, LongRef paramLongRef) {
    CK_RV cK_RV = CTUtil.CTU_GetMechanismTypeString(paramCK_MECHANISM_TYPE, paramArrayOfbyte, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("CTU_GetMechanismTypeString", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV CTU_DerEncodeNamedCurve(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, LongRef paramLongRef) {
    CK_RV cK_RV = CTUtil.CTU_DerEncodeNamedCurve(paramArrayOfbyte1, paramArrayOfbyte2, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("CTU_DerEncodeNamedCurve", cK_RV); 
    return cK_RV;
  }
  
  public static CK_MECHANISM_TYPE CTU_GetMechanismTypeValue(byte[] paramArrayOfbyte) {
    return CTUtil.CTU_GetMechanismTypeValue(paramArrayOfbyte);
  }
  
  public static CK_RV CTU_GetSessionStateString(CK_STATE paramCK_STATE, byte[] paramArrayOfbyte, LongRef paramLongRef) {
    CK_RV cK_RV = CTUtil.CTU_GetSessionStateString(paramCK_STATE, paramArrayOfbyte, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("CTU_GetSessionStateString", cK_RV); 
    return cK_RV;
  }
  
  public static CK_STATE CTU_GetSessionStateValue(byte[] paramArrayOfbyte) {
    return CTUtil.CTU_GetSessionStateValue(paramArrayOfbyte);
  }
  
  public static CK_RV CTU_FindObject(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_OBJECT_CLASS paramCK_OBJECT_CLASS, byte[] paramArrayOfbyte, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE) {
    CK_RV cK_RV = CTUtil.CTU_FindObject(paramCK_SESSION_HANDLE, paramCK_OBJECT_CLASS, paramArrayOfbyte, paramCK_OBJECT_HANDLE);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("CTU_FindObject", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV CTU_GetAttributeValue(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE, CK_ATTRIBUTE_TYPE paramCK_ATTRIBUTE_TYPE, Object paramObject, long paramLong, LongRef paramLongRef) {
    CK_RV cK_RV = CTUtil.CTU_GetAttributeValue(paramCK_SESSION_HANDLE, paramCK_OBJECT_HANDLE, paramCK_ATTRIBUTE_TYPE, paramObject, paramLong, paramLongRef);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("CTU_GetAttributeValue", cK_RV); 
    return cK_RV;
  }
  
  public static CK_RV CTU_SetAttributeValue(CK_SESSION_HANDLE paramCK_SESSION_HANDLE, CK_OBJECT_HANDLE paramCK_OBJECT_HANDLE, CK_ATTRIBUTE_TYPE paramCK_ATTRIBUTE_TYPE, Object paramObject, long paramLong) {
    CK_RV cK_RV = CTUtil.CTU_SetAttributeValue(paramCK_SESSION_HANDLE, paramCK_OBJECT_HANDLE, paramCK_ATTRIBUTE_TYPE, paramObject, paramLong);
    if (!cK_RV.equals(CKR.OK))
      throw new CKR_Exception("CTU_SetAttributeValue", cK_RV); 
    return cK_RV;
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/CTUtilEx.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */