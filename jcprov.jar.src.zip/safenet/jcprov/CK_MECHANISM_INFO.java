package safenet.jcprov;

public class CK_MECHANISM_INFO {
  public long minKeySize;
  
  public long maxKeySize;
  
  public long flags;
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/CK_MECHANISM_INFO.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */