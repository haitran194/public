package safenet.jcprov;

public class CK_OBJECT_HANDLE {
  private long m_value = 0L;
  
  public CK_OBJECT_HANDLE() {}
  
  public CK_OBJECT_HANDLE(long paramLong) {}
  
  public long longValue() {
    return this.m_value;
  }
  
  public boolean isValidHandle() {
    return !(this.m_value == 0L);
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/CK_OBJECT_HANDLE.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */