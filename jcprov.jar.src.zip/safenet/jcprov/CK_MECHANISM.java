package safenet.jcprov;

import safenet.jcprov.constants.CK_MECHANISM_TYPE;

public class CK_MECHANISM {
  public CK_MECHANISM_TYPE mechanism;
  
  public Object pParameter;
  
  public long parameterLen;
  
  public CK_MECHANISM() {}
  
  public CK_MECHANISM(CK_MECHANISM_TYPE paramCK_MECHANISM_TYPE, Object paramObject, long paramLong) {
    this.mechanism = paramCK_MECHANISM_TYPE;
    this.pParameter = paramObject;
    this.parameterLen = paramLong;
  }
  
  public CK_MECHANISM(CK_MECHANISM_TYPE paramCK_MECHANISM_TYPE) {
    this.mechanism = paramCK_MECHANISM_TYPE;
    Object object = paramCK_MECHANISM_TYPE.getDefaultParameter();
    this.pParameter = object;
    if (object == null) {
      this.parameterLen = 0L;
    } else {
      this.parameterLen = getMechanismParameterSize(object);
    } 
  }
  
  public CK_MECHANISM(CK_MECHANISM_TYPE paramCK_MECHANISM_TYPE, Object paramObject) {
    this.mechanism = paramCK_MECHANISM_TYPE;
    this.pParameter = paramObject;
    this.parameterLen = getMechanismParameterSize(paramObject);
  }
  
  static native long getMechanismParameterSize(Object paramObject);
  
  static {
    System.loadLibrary("jcprov");
  }
}


/* Location:              /Users/dovd/Downloads/testnative 2/lib/jcprov.jar!/safenet/jcprov/CK_MECHANISM.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */