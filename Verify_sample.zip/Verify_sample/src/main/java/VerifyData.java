
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.RSAEncrypter;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Primitive;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.x509.Certificate;
import org.bouncycastle.jce.provider.X509CertificateObject;
import org.bouncycastle.util.io.pem.PemObject;
import org.bouncycastle.util.io.pem.PemReader;
import org.jose4j.jwa.AlgorithmConstraints;
import org.jose4j.jwe.ContentEncryptionAlgorithmIdentifiers;
import org.jose4j.jwe.JsonWebEncryption;
import org.jose4j.jwe.KeyManagementAlgorithmIdentifiers;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.keys.AesKey;

import javax.crypto.KeyGenerator;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.*;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Date;

public class VerifyData {

    static {
        Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
    }

    public static void main(String[] args) {
        try {
            String response = "{\"errorCode\":\"317\",\"errorDesc\":\"Giao dich can xac thuc deeplink hoac QR(317)\",\"bidvTraceNumber\":\"|21601536\",\"isPartnerAuthen\":\"\",\"typeCode\":\"C\",\"deeplink\":\"bidv.smartbanking.partner://ewallet?source=PAYGATE_EWALLET&data=&signature=\",\"qrImage\":\"\"}";

            // Sử dụng Gson để phân tích chuỗi JSON
            JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();

            // Tuần tự hóa lại đối tượng JSON mà không có các ký tự trắng thừa
            String compactResponse = jsonObject.toString();

            System.out.println(compactResponse);

            VerifyData verifyData = new VerifyData();

            String jws_response = "eyJhbGciOiJSUzI1NiJ9..dZBBfDKnhYZWxB4DQgiE_vklJlYHAZofYktG6e1f3Tf1vAJYVqOUIoHWPUTV7Rj5nQdD352zW16iUr6WPxbmrn9Le0W0eatQc7_9ZmRVRFH55dVWZkEMHQJ2rpXXkUWWfeLrCHs57tu7YUxzqUZhbfG7Aq4_3oYPQxhSw7tORsfbSa5dtMeuOCpVALCZLw9JAd05SVTr-9pFceY7wGyabllIDhd8bv0cX_GxE7m0oRvrfngDm-czMrk-XpcTgTZ1UPmaluMTaLKIAFQ-orvIicjAwBIUAUowErgkG2NRg4gd_Z7RpXLClAlVbNCNyDfhJNJFjHg4nv3vWc0SQBw28w";

            boolean verify = verifyData.verifyJws(compactResponse, jws_response, "src/main/resources/cert/publickey.pem");
            System.out.println("verify: " + verify);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Load cert to publicKey
     *
     * @param certPath - Public cert path
     * @return PublicKey
     */
    private PublicKey loadCertificate(String certPath) throws IOException, GeneralSecurityException {
        String certStr = new String(Files.readAllBytes(Paths.get(certPath)));
        certStr = certStr.replaceAll("-----(BEGIN|END) CERTIFICATE-----", "").replaceAll("\n|\r", "");
        System.out.println("certStr: " + certStr);
        byte[] data = Base64.getDecoder().decode(certStr.getBytes("UTF-8"));
        ByteArrayInputStream inStream = new ByteArrayInputStream(data);
        ASN1InputStream derin = new ASN1InputStream(inStream);
        ASN1Primitive certInfo = derin.readObject();
        ASN1Sequence seq = ASN1Sequence.getInstance(certInfo);
        X509Certificate cert = new X509CertificateObject(Certificate.getInstance(seq));
        System.out.println(cert.getSigAlgName());
        return cert.getPublicKey();
    }

    /**
     * Verify A JWS
     *
     * @param response      - Response from OpenApi
     * @param jws           - JWS Compact Serialization Format
     * @param publicKeyPath - Public Key
     * @return
     */
    public boolean verifyJws(String response, String jws, String publicKeyPath) {
        try {
            String base64 = buildResponseToBase64(response);
            System.out.println("base64: " + base64);
            String _jws = jws.replace("..", String.format("%s%s%s", ".", base64, "."));
            System.out.println("_jws: " + _jws);
            RSAPublicKey rsaPublicKey = (RSAPublicKey) loadCertificate(publicKeyPath);
            JWSVerifier verifier = new RSASSAVerifier(rsaPublicKey);
            JWSObject jwsObject = JWSObject.parse(_jws);
            System.out.println("payload: " + jwsObject.getPayload());
            return jwsObject.verify(verifier);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private String replaceLast(String text, String regex, String replacement) {
        return text.replaceFirst("(?s)" + regex + "(?!.*?" + regex + ")", replacement);
    }

    private String buildResponseToBase64(String response) throws Exception {
        Gson gson = new Gson();
        JsonObject convertedObject = gson.fromJson(response, JsonObject.class);
        System.out.println("json: " + convertedObject.toString());
        String base64 = Base64.getUrlEncoder().encodeToString(convertedObject.toString().getBytes());
        return replaceLast(base64, "=+", "");
    }

}
